# =============================================================================
# engine.py  -  The pure game logic for Ogatu. NO pygame import here.
#
# Keeping all rules separate from rendering lets us unit-test the actual
# gameplay (boulders fall; a crushed firefly blows a hole, a crushed butterfly
# becomes diamonds; the exit opens; touching any enemy kills you) without ever
# opening a window. The renderer in
# game.py just draws whatever state this module produces.
#
# Mental model:
#   * The cave is a 2D grid of single-character tiles (see constants.py).
#   * Ranganna (the player) and the fireflies are "entities" with (row, col)
#     positions that float ABOVE the grid - they always stand on an EMPTY cell.
#   * Boulders and diamonds live INSIDE the grid as tiles, because they can be
#     dug, pushed, fall, and (for boulders) crush things.
#   * Gravity points DOWN the screen (toward higher row numbers).
# =============================================================================

import copy
from collections import deque
from constants import (
    WALL, DIRT, EMPTY, BOULDER, DIAMOND, EXIT,
    PLAYER_SPAWN, FIREFLY_SPAWN, BUTTERFLY_SPAWN, HUNTER_SPAWN, BOULDER_SUPPORTS,
    BOMB, START_BOMBS, DIAMONDS_PER_BOMB, BOMB_FUSE_TICKS,
    LEVELS,
)

# ---- Cardinal directions (dr, dc). row increases downward, col rightward ----
UP    = (-1,  0)
DOWN  = ( 1,  0)
LEFT  = ( 0, -1)
RIGHT = ( 0,  1)

# Wall-following rotations. A "left-handed" firefly keeps a wall on its left,
# so it always TRIES to turn left first, then straight, then right, then back.
LEFT_OF  = {UP: LEFT,  LEFT: DOWN, DOWN: RIGHT, RIGHT: UP}   # counter-clockwise
RIGHT_OF = {UP: RIGHT, RIGHT: DOWN, DOWN: LEFT, LEFT: UP}   # clockwise
AROUND   = {UP: DOWN,  DOWN: UP,   LEFT: RIGHT, RIGHT: LEFT}

# Enemy kinds. The cave has two mobile enemies that are mirror images of each
# other: they share the same (row, col, facing) structure and the same
# wall-following movement, but turn in OPPOSITE directions and explode into
# different things when a boulder crushes them.
#   FIREFLY   - left-handed patrol; crush -> 3x3 blown EMPTY (dirt cleared).
#   BUTTERFLY - right-handed patrol; crush -> 3x3 becomes DIAMONDS (reward).
FIREFLY = "firefly"
BUTTERFLY = "butterfly"

# A HUNTER is the dangerous third enemy. Instead of wall-following it actively
# CHASES the player along the shortest open path (BFS - see step_hunters). It
# can't dig, so undug dirt and walls are the player's refuge. Crush split:
# hunter -> DIAMONDS (like a butterfly - the reward for luring it under a rock).
# It moves on its own slower timer (HUNTER_MS) so you can outrun it in the open.
HUNTER = "hunter"

# Per-level outcome.
PLAYING, WON, LOST = "playing", "won", "lost"


class Level:
    """One Boulder Dash cave: its tiles, entities, and all the rules."""

    def __init__(self, grid, player, enemies, exit_pos,
                 diamonds_required, diamonds_collected=0, enemies_crushed=0):
        self.grid = grid                 # list[list[str]] of tile chars
        self.rows = len(grid)
        self.cols = len(grid[0]) if grid else 0
        self.player = player             # (row, col)
        self.player_facing = RIGHT       # for rendering / push direction
        self.enemies = enemies           # list of [row, col, facing, kind]
        self.exit_pos = exit_pos         # (row, col)
        self.diamonds_required = diamonds_required
        self.diamonds_collected = diamonds_collected
        self.enemies_crushed = enemies_crushed  # fireflies + butterflies
        self.status = PLAYING            # PLAYING / WON / LOST
        self.falling = set()             # (r,c) of boulders/diamonds in free-fall
        # ---- dynamite state (all reset fresh per cave via from_map) ----
        self.bombs = {}                     # (r,c) -> remaining fuse ticks
        self.bombs_inventory = START_BOMBS  # bombs in hand right now
        self.diamonds_spent = 0             # diamonds spent in the store

    # ---- construction ------------------------------------------------------
    @classmethod
    def from_map(cls, lines):
        """Parse an ASCII level (list of strings) into a live Level."""
        # Pad every row to the width of the widest row with WALL, so the cave
        # is always a clean rectangle.
        width = max(len(line) for line in lines)
        grid = [list(line.ljust(width, WALL)) for line in lines]

        player = None
        enemies = []          # each entry: [row, col, facing, kind]
        exit_pos = None
        diamonds = 0

        for r in range(len(grid)):
            for c in range(width):
                ch = grid[r][c]
                if ch == PLAYER_SPAWN:
                    player = (r, c)
                    grid[r][c] = EMPTY          # spawn cell becomes open floor
                elif ch == FIREFLY_SPAWN:
                    # A firefly remembers which way it faces. Start facing LEFT
                    # so it immediately begins patrolling that way.
                    enemies.append([r, c, LEFT, FIREFLY])
                    grid[r][c] = EMPTY
                elif ch == BUTTERFLY_SPAWN:
                    # A butterfly is the firefly's mirror image. It also starts
                    # facing LEFT but follows the OPPOSITE wall (right-handed).
                    enemies.append([r, c, LEFT, BUTTERFLY])
                    grid[r][c] = EMPTY
                elif ch == HUNTER_SPAWN:
                    # A hunter chases the player (BFS in step_hunters), unlike
                    # the wall-following firefly/butterfly. Facing is cosmetic
                    # for it; start facing LEFT like the rest.
                    enemies.append([r, c, LEFT, HUNTER])
                    grid[r][c] = EMPTY
                elif ch == DIAMOND:
                    diamonds += 1
                elif ch == EXIT:
                    exit_pos = (r, c)

        if player is None:
            raise ValueError("Level has no player spawn 'P'")
        if exit_pos is None:
            raise ValueError("Level has no exit 'E'")

        return cls(grid, player, enemies, exit_pos, diamonds)

    # ---- small helpers -----------------------------------------------------
    def in_bounds(self, r, c):
        return 0 <= r < self.rows and 0 <= c < self.cols

    def cell(self, r, c):
        return self.grid[r][c]

    def exit_active(self):
        # The exit unlocks only once every diamond in the cave has been taken.
        return self.diamonds_collected >= self.diamonds_required

    def wallet(self):
        """Spendable diamonds = dug up MINUS spent in the store. The exit uses
        diamonds_collected (never reduced by spending), so buying bombs can
        never re-lock a cave - this is purely the store's currency."""
        return self.diamonds_collected - self.diamonds_spent

    def _enemy_at(self, r, c):
        """True if ANY enemy (firefly or butterfly) occupies (r, c)."""
        return any(f[0] == r and f[1] == c for f in self.enemies)

    def _enemy_kind_at(self, r, c):
        """The kind ('firefly'/'butterfly') of the enemy at (r,c), or None."""
        for f in self.enemies:
            if f[0] == r and f[1] == c:
                return f[3]
        return None

    # ---- player action -----------------------------------------------------
    def move_player(self, direction):
        """
        Try to move Ranganna one tile in `direction`. This single call handles
        every interaction: digging dirt, collecting diamonds, pushing boulders,
        entering the (active) exit, and dying by walking into a firefly.
        """
        if self.status != PLAYING:
            return
        dr, dc = direction
        r, c = self.player
        nr, nc = r + dr, c + dc
        self.player_facing = direction

        if not self.in_bounds(nr, nc):
            return
        target = self.cell(nr, nc)

        if target == WALL:
            return  # solid steel - never passable

        if target == DIRT:
            # Dig: turn the dirt into open floor and step onto it.
            self.grid[nr][nc] = EMPTY
            self.player = (nr, nc)

        elif target == DIAMOND:
            # Collect the gem, then step onto the now-empty cell.
            self.grid[nr][nc] = EMPTY
            self.diamonds_collected += 1
            self.player = (nr, nc)

        elif target == EMPTY:
            # Open tunnel - but if a firefly is standing there, it's a kill.
            if self._enemy_at(nr, nc):
                self.status = LOST
                return
            self.player = (nr, nc)

        elif target == EXIT:
            # Only enter the exit once all diamonds are collected.
            if self.exit_active():
                self.player = (nr, nc)
                self.status = WON
            # else: the locked door blocks you - do nothing.

        elif target == BOMB:
            # A live, ticking bomb is impassable: you plant it on your OWN cell
            # and step off, never back on. Enemies skip it too (they only enter
            # EMPTY), so a planted bomb briefly blocks a chasing hunter.
            return

        elif target == BOULDER:
            # Boulder Dash rule: you can only PUSH a boulder sideways (left or
            # right), and only if the tile beyond it is open. Up/down pushes
            # are impossible (you can't lift a rock, and pushing down would
            # just be the rock falling).
            if direction in (LEFT, RIGHT):
                br, bc = nr + dr, nc + dc
                if (self.in_bounds(br, bc)
                        and self.cell(br, bc) == EMPTY
                        and not self._enemy_at(br, bc)
                        and (br, bc) != self.player):
                    self.grid[br][bc] = BOULDER   # rock slides one tile over
                    self.grid[nr][nc] = EMPTY     # its old cell opens up
                    self.player = (nr, nc)        # you walk into the old cell
            # vertical push attempt -> blocked, do nothing

    # ---- dynamite: planting + buying --------------------------------------
    def place_bomb(self):
        """Plant a bomb on Ranganna's current cell (he stands on EMPTY floor),
        spending one from inventory. He must then get at least TWO cells away
        before the fuse runs out or his own 3x3 blast catches him. Returns True
        if a bomb was actually planted."""
        if self.status != PLAYING or self.bombs_inventory <= 0:
            return False
        r, c = self.player
        if self.grid[r][c] != EMPTY:   # a bomb is already here (he hasn't moved)
            return False
        self.grid[r][c] = BOMB
        self.bombs[(r, c)] = BOMB_FUSE_TICKS
        self.bombs_inventory -= 1
        return True

    def buy_bomb(self):
        """Store purchase: trade DIAMONDS_PER_BOMB wallet diamonds for one bomb.
        Spends the wallet WITHOUT touching diamonds_collected, so the exit can
        never re-lock. Returns True on a successful buy, False if too poor."""
        if self.wallet() < DIAMONDS_PER_BOMB:
            return False
        self.diamonds_spent += DIAMONDS_PER_BOMB
        self.bombs_inventory += 1
        return True

    # ---- gravity (boulders and diamonds fall) ----------------------------
    def step_gravity(self):
        """
        Advance every boulder and diamond by one tick of gravity. Scan
        BOTTOM-to-TOP so a single object can't fall more than one tile per
        tick (by the time it lands on the row below, that row is done).

        Crush rule (authentic Boulder Dash):
          A boulder only crushes the player or a firefly if it has actually
          been FALLING (in motion) for at least one tick. A RESTING boulder
          that just lost its support does NOT crush on that first tick -
          it rests on whatever is directly below (the player or a firefly
          acts as a support for one tick), giving Ranganna a fair chance to
          step away. This matches the original: "standing one square under a
          resting boulder never kills you; only a boulder already in motion
          does." Diamonds never crush anything - they just rest on whatever
          is below them.
        """
        if self.status != PLAYING:
            return
        # Positions in free-fall AFTER this tick. An object enters this set
        # the instant it moves down a tile, and leaves it the moment it comes
        # to rest (or rests on the player / a firefly / solid ground).
        new_falling = set()
        for r in range(self.rows - 1, -1, -1):       # bottom row first
            for c in range(self.cols):
                tile = self.grid[r][c]
                if tile != BOULDER and tile != DIAMOND:
                    continue
                br, bc = r + 1, c                    # the tile directly below
                if not self.in_bounds(br, bc):
                    continue                         # edge of grid (walls border)
                below = self.grid[br][bc]
                was_falling = (r, c) in self.falling

                # Solid support below -> the object rests where it is.
                if below in BOULDER_SUPPORTS:
                    continue                         # resting; not in new_falling

                # The cell below is EMPTY. Decide who, if anyone, is there.
                if self.player == (br, bc):
                    if tile == BOULDER and was_falling:
                        # A rock in motion lands on Ranganna -> crushed.
                        self.status = LOST
                        self.grid[r][c] = EMPTY
                        self.grid[br][bc] = BOULDER  # leave rock on him visually
                        return
                    # A resting boulder, or ANY diamond -> it rests on
                    # Ranganna's head (he acts as a support). No crush, no
                    # fall this tick. He can step away on his next move.
                    continue

                if self._enemy_at(br, bc):
                    if tile == BOULDER and was_falling:
                        # A rock in motion crushes the enemy below. The blast
                        # depends on the enemy's kind (authentic Boulder Dash):
                        #   firefly   -> 3x3 blown EMPTY (dirt cleared, no gems)
                        #   butterfly -> 3x3 becomes DIAMONDS (the reward)
                        if self._enemy_kind_at(br, bc) in (BUTTERFLY, HUNTER):
                            self._explode(br, bc)
                        else:
                            self._explode_empty(br, bc)
                        self.grid[r][c] = EMPTY
                        self.enemies_crushed += 1
                        self._remove_enemy(br, bc)
                        continue
                    # Resting boulder, or diamond -> rests on the enemy (it
                    # acts as support) until it wanders off next tick.
                    continue

                # Truly empty space with nobody under it -> drop one tile.
                self.grid[r][c] = EMPTY
                self.grid[br][bc] = tile
                new_falling.add((br, bc))
        self.falling = new_falling

    def _explode(self, r, c):
        """Butterfly blast: turn a 3x3 area of dirt/empty into DIAMONDS."""
        for dr in (-1, 0, 1):
            for dc in (-1, 0, 1):
                rr, cc = r + dr, c + dc
                if not self.in_bounds(rr, cc):
                    continue
                if self.grid[rr][cc] in (DIRT, EMPTY):
                    self.grid[rr][cc] = DIAMOND
        # Note: these are BONUS diamonds. The exit opens at diamonds_required,
        # which is fixed when the level loads, so crushing a butterfly never
        # forces extra collection - it only rewards you with spare gems.

    def _explode_empty(self, r, c):
        """Firefly blast: blow the 3x3 area around (r,c) clear. Dirt becomes
        empty and no gems are left behind - the firefly just wrecks the cave."""
        for dr in (-1, 0, 1):
            for dc in (-1, 0, 1):
                rr, cc = r + dr, c + dc
                if not self.in_bounds(rr, cc):
                    continue
                if self.grid[rr][cc] in (DIRT, EMPTY):
                    self.grid[rr][cc] = EMPTY

    def _remove_enemy(self, r, c):
        self.enemies = [f for f in self.enemies if not (f[0] == r and f[1] == c)]

    # ---- dynamite: fuse + detonation --------------------------------------
    def step_bombs(self):
        """Tick every planted bomb's fuse down by one; detonate those that hit
        zero. Returns the list of (r,c) detonation centres so the renderer can
        spark blast particles. Driven by its own BOMB_MS timer in game.py."""
        if self.status != PLAYING or not self.bombs:
            return []
        detonated = []
        for pos in list(self.bombs):
            self.bombs[pos] -= 1
            if self.bombs[pos] <= 0:
                detonated.append(pos)
        for (r, c) in detonated:
            # An earlier blast THIS tick may already have cleared this bomb
            # (two bombs within each other's radius) - skip the duplicate.
            if self.bombs.pop((r, c), None) is None:
                continue
            if self.grid[r][c] == BOMB:
                self.grid[r][c] = EMPTY
            self._blast(r, c)
        return detonated

    def _blast(self, r, c):
        """Detonate at (r,c): a 3x3 explosion. Dirt is cleared, boulders are
        smashed to empty, and any enemy caught is killed (+enemies_crushed).
        WALLS, DIAMONDS and the EXIT survive (cave border + gems + objective
        protected). If Ranganna stands anywhere in the 3x3, his OWN blast kills
        him (run or die). A neighbouring bomb is cleared (no chain in v1)."""
        for dr in (-1, 0, 1):
            for dc in (-1, 0, 1):
                rr, cc = r + dr, c + dc
                if not self.in_bounds(rr, cc):
                    continue
                if self.player == (rr, cc):
                    self.status = LOST
                if self._enemy_at(rr, cc):
                    self.enemies_crushed += 1
                    self._remove_enemy(rr, cc)
                tile = self.grid[rr][cc]
                if tile in (DIRT, EMPTY, BOULDER):
                    self.grid[rr][cc] = EMPTY
                elif tile == BOMB:
                    self.grid[rr][cc] = EMPTY
                    self.bombs.pop((rr, cc), None)
                # WALL / DIAMOND / EXIT are left untouched - they survive.

    # ---- enemies (fireflies and butterflies patrol) -----------------------
    def step_enemies(self):
        """
        Every enemy takes one step using wall-following. A FIREFLY keeps a wall
        on its LEFT (left-handed): turn left, else straight, else right, else
        U-turn. A BUTTERFLY is the mirror image - it keeps a wall on its RIGHT
        (right-handed): right, straight, left, U-turn. If an enemy's chosen
        step lands on Ranganna, he dies. Enemies only walk through EMPTY
        tunnels (they don't dig).
        """
        if self.status != PLAYING:
            return
        for enemy in list(self.enemies):
            if self.status != PLAYING:
                break
            r, c, facing, kind = enemy
            if kind == HUNTER:
                continue  # hunters chase in step_hunters(), not wall-following
            # Mirror-image turn orders: fireflies turn left first, butterflies
            # turn right first. The "straight, opposite-turn, U-turn" tail and
            # the kill-on-contact rule are shared by both kinds.
            first = LEFT_OF[facing] if kind == FIREFLY else RIGHT_OF[facing]
            third = RIGHT_OF[facing] if kind == FIREFLY else LEFT_OF[facing]
            for d in (first, facing, third, AROUND[facing]):
                nr, nc = r + d[0], c + d[1]
                if not self.in_bounds(nr, nc):
                    continue
                # Walking onto Ranganna is a kill (the "avoid enemies" rule).
                if (nr, nc) == self.player:
                    self.status = LOST
                    enemy[0], enemy[1], enemy[2] = nr, nc, d
                    break
                # Otherwise the enemy only enters open tunnel cells that are
                # not already occupied by another enemy.
                if self.grid[nr][nc] == EMPTY and not self._enemy_at(nr, nc):
                    enemy[0], enemy[1], enemy[2] = nr, nc, d
                    break
            # If nothing worked, the enemy is boxed in; it just turns around
            # in place and will try again next tick.

    # ---- hunters (chase the player along open tunnels) -------------------
    def _player_distance_field(self):
        """BFS distances from the player's cell to every EMPTY cell reachable
        through open tunnels (4-connected). Hunters descend this gradient to
        chase. Dirt / wall / boulder / diamond cells are NOT traversable, so
        they never appear here - undug dirt is the player's refuge."""
        pr, pc = self.player
        dist = {(pr, pc): 0}
        queue = deque([(pr, pc)])
        while queue:
            r, c = queue.popleft()
            for dr, dc in (UP, DOWN, LEFT, RIGHT):
                nr, nc = r + dr, c + dc
                if not self.in_bounds(nr, nc) or (nr, nc) in dist:
                    continue
                if self.grid[nr][nc] == EMPTY:
                    dist[(nr, nc)] = dist[(r, c)] + 1
                    queue.append((nr, nc))
        return dist

    def step_hunters(self):
        """Move every HUNTER one step toward the player along the SHORTEST open
        path. One BFS distance-field (shared by all hunters) is computed from
        the player; each hunter steps onto its lowest-distance open neighbour
        (descending the gradient = shortest path). If that neighbour is the
        player, it pounces (a kill). A hunter walled in by dirt with no open
        path simply waits. Hunters never dig and never share a cell with another
        enemy. Driven by its own slower timer (HUNTER_MS) so the player can
        outrun it in open space."""
        if self.status != PLAYING:
            return
        hunters = [e for e in self.enemies if e[3] == HUNTER]
        if not hunters:
            return
        dist = self._player_distance_field()
        for hunter in hunters:
            if self.status != PLAYING:
                break
            r, c = hunter[0], hunter[1]
            best = None       # (distance_to_player, nr, nc, direction)
            pounced = False
            for d in (UP, DOWN, LEFT, RIGHT):
                nr, nc = r + d[0], c + d[1]
                if not self.in_bounds(nr, nc):
                    continue
                if (nr, nc) == self.player:
                    # Adjacent to Ranganna -> pounce, regardless of gradient.
                    self.status = LOST
                    hunter[0], hunter[1], hunter[2] = nr, nc, d
                    pounced = True
                    break
                # Otherwise chase only through reachable open tunnels that no
                # other enemy already occupies.
                if (nr, nc) in dist and not self._enemy_at(nr, nc):
                    cand = (dist[(nr, nc)], nr, nc, d)
                    if best is None or cand < best:
                        best = cand
            if pounced:
                break
            if best is not None:
                _, nr, nc, d = best
                hunter[0], hunter[1], hunter[2] = nr, nc, d

    # ---- convenience -------------------------------------------------------
    def snapshot(self):
        """A human-readable view of the cave (handy for tests/debugging)."""
        g = [row[:] for row in self.grid]
        if self.player:
            pr, pc = self.player
            g[pr][pc] = "@"
        for (fr, fc, _, kind) in self.enemies:
            g[fr][fc] = {BUTTERFLY: "b", HUNTER: "h"}.get(kind, "f")
        return "\n".join("".join(row) for row in g)


def load_level(index):
    """Build the Level for LEVELS[index]."""
    return Level.from_map(LEVELS[index])
