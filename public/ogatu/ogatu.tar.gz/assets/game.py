# =============================================================================
# game.py  -  The pygame renderer + input + main loop for Ogatu.
#
# This file knows NOTHING about the game rules. It only:
#   1. reads the Level state that engine.py produces,
#   2. draws it to the screen,
#   3. feeds keyboard input into engine.move_player / reloads levels on death.
#
# Keeping rules (engine.py) separate from presentation (this file) is what let
# us unit-test the gameplay headlessly. If the visuals are ever wrong but the
# tests pass, the bug is in here; if the tests fail, the bug is in engine.py.
#
# Juice layer (added Session 02): dig-dust particles, screen shake on crush /
# firefly explosion, falling-boulder danger tint, diamond glow pulse, animated
# title. All of this is pure presentation - the engine is never touched.
# =============================================================================

import asyncio
import logging
import math
import random
from datetime import datetime
from pathlib import Path

import pygame

from constants import (
    TILE_SIZE, HUD_HEIGHT, FPS,
    MOVE_INITIAL_MS, MOVE_REPEAT_MS, GRAV_MS, ENEMY_MS, HUNTER_MS, BOMB_MS,
    START_LIVES, DIAMOND_SCORE, ENEMY_SCORE, DIAMONDS_PER_BOMB,
    LEVEL_COLS, LEVEL_ROWS, LEVELS, LEVEL_NAMES,
    WALL, DIRT, EMPTY, BOULDER, DIAMOND, EXIT, BOMB,
    COL_BG, COL_EMPTY, COL_WALL, COL_DIRT, COL_BOULDER, COL_DIAMOND,
    COL_EXIT_OFF, COL_EXIT_ON, COL_PLAYER, COL_FIREFLY, COL_BUTTERFLY, COL_HUNTER,
    COL_HUD, COL_HUD_LINE, COL_TEXT, COL_TEXT_DIM, COL_GOOD, COL_BAD,
    COL_BOMB, COL_BOMB_SPARK,
)
from engine import load_level, UP, DOWN, LEFT, RIGHT, PLAYING, WON, LOST, BUTTERFLY, HUNTER
from sound import SfxBank

# Window size is derived from the level grid so everything always fits.
W = LEVEL_COLS * TILE_SIZE
H = HUD_HEIGHT + LEVEL_ROWS * TILE_SIZE

# Map physical keys -> in-game directions (both arrows and WASD). Filled LAZILY
# by _build_key_map() instead of as a literal here: in the WebAssembly/pygbag
# build, pygame's K_* key constants don't exist until pygame.init() has run, so
# referencing them at IMPORT time (which a desktop build happily allows) crashes
# the web build before it starts. We populate this same dict in-place from
# Game.__init__, right after pygame.init().
KEY_TO_DIR = {}


def _build_key_map():
    """Fill KEY_TO_DIR once pygame's key constants exist (after pygame.init()).
    Idempotent - safe to call on every Game construction."""
    KEY_TO_DIR.update({
        pygame.K_UP: UP, pygame.K_w: UP,
        pygame.K_DOWN: DOWN, pygame.K_s: DOWN,
        pygame.K_LEFT: LEFT, pygame.K_a: LEFT,
        pygame.K_RIGHT: RIGHT, pygame.K_d: RIGHT,
    })

# Screen-shake durations (ms) for each trigger event.
SHAKE_ON_CRUSH = 450       # player crushed by a boulder - big jolt
SHAKE_ON_EXPLODE = 350     # firefly exploded into diamonds - medium rumble

# Intro cutscene timings (ms). The walk-into-cave sequence plays once on launch
# and again on a full-game restart (Game Over / Victory). Pressing any key
# skips it. All renderer-only - the engine never sees these.
INTRO_WALK_MS = 2200       # Ranganna walks from the left edge to the cave mouth
INTRO_ENTER_MS = 600       # he shrinks and fades as he steps into the darkness
INTRO_FADE_MS = 500        # the whole screen fades to black, then gameplay begins
INTRO_SKIP_GUARD_MS = 250  # min time before a key can skip (prevents a held
                           # title-screen key from instantly cancelling the intro)
INTRO_BLACK_HOLD_MS = 1000  # pure black screen held for this long after the
                            # cutscene, before gameplay begins (a cinematic beat)
INTRO_MUSIC_FADE_MS = 200   # a MILD fade easing the clip's tail into the black
                            # hold (shorter than the old 400ms, which felt heavy)

# The playable characters. Each is defined purely by colours + an optional
# accessory, all rendered from simple geometric shapes in _draw_avatar().
# Adding a fourth character is just appending a dict here.
AVATARS = [
    {
        "name": "RANGANNA",
        "body": (255, 214, 70),          # classic yellow explorer
        "rim":  (120, 90, 0),
        "eye":  (40, 30, 0),
        "accessory": None,
    },
    {
        "name": "AVYAN",
        "body": (80, 160, 240),           # blue adventurer with a red cap
        "rim":  (30, 70, 140),
        "eye":  (30, 20, 10),
        "accessory": "cap",
        "acc_col": (220, 60, 50),
    },
    {
        "name": "AVNI",
        "body": (240, 130, 200),          # pink explorer with pigtails
        "rim":  (140, 50, 110),
        "eye":  (40, 20, 30),
        "accessory": "pigtails",
        "acc_col": (200, 100, 160),
    },
]


# The options shown on the HOME menu. Index 0 must stay the "start the game"
# entry - _on_keydown ties that index to start_new_game(). Adding a new entry
# here (e.g. a future "Level Editor") makes the menu render + navigate it free.
MENU_ITEMS = [
    "START GAME",
    "SELECT CHARACTER",
    "LEVEL SELECT",
]

# The Pause-screen options (shown when ESC is pressed during play). Index 0 is
# RESUME so the cursor starts on the safest choice; _on_keydown maps each label
# to its action.
PAUSE_ITEMS = [
    "RESUME",
    "QUIT TO MENU",
    "QUIT GAME",
]

# The Store's stock, shown when the player opens the shop with B during play.
# This is append-only: a future item (extra life, shield, dig-through-rock...)
# is just another dict here, and the store screen + buy flow pick it up for
# free. v1 stocks one item - Dynamite. `action` is matched in _buy_selected.
STORE_ITEMS = [
    {"name": "DYNAMITE", "cost": DIAMONDS_PER_BOMB, "action": "bomb",
     "blurb": "plant with SPACE  -  3x3 blast clears dirt, smashes rock, kills foes"},
]


# ---- per-session logging ----------------------------------------------------
# Each launch writes its own timestamped file under logs/ (gitignored), so every
# play session - Avyan's, Avni's, a test run - is isolated and easy to review or
# share. We use the standard `logging` module: idiomatic, and keeps timestamps
# and formatting consistent. Logging is pure observability - it never affects
# gameplay - and if the log dir can't be written the game still runs (a
# NullHandler fallback silently drops every message).
LOG_DIR = Path("logs")


def setup_logging():
    """Create a per-session log file under logs/ and return a configured logger.

    Returns the module-level "gamedigger" logger. On the first call it attaches a
    FileHandler writing to logs/session_YYYYMMDD_HHMMSS.log; later calls reuse
    the same logger (handlers aren't re-added). If the directory can't be created
    or written, a NullHandler is attached so `self.log.info(...)` becomes a safe
    no-op instead of crashing the game.
    """
    log = logging.getLogger("gamedigger")
    log.setLevel(logging.INFO)
    if log.handlers:                       # __init__ should only run once,
        return log                         # but guard against double handlers
    try:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        handler = logging.FileHandler(LOG_DIR / f"session_{stamp}.log",
                                      encoding="utf-8")
        handler.setFormatter(logging.Formatter(
            "%(asctime)s %(levelname)-5s %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"))
        log.addHandler(handler)
    except OSError:
        # Read-only location, disk full, etc. - never let logging break the game.
        log.addHandler(logging.NullHandler())
    return log


# The intro cutscene's backing clip. Played once when a new game begins (the
# walk-into-cave animation) and stopped when the intro ends or is skipped. This
# is the project's ONE asset file - a deliberate exception for a specific clip
# the family chose; every other sound will be generated procedurally.
INTRO_CLIP = "game_clip2.ogg"   # OGG (not MP3): the browser/wasm mixer decodes
                                # OGG reliably; desktop pygame plays it too.

class Game:
    """Owns the window, the current level, score/lives, and the game loop."""

    HOME = "home"                       # main menu: Start Game / Select Character
    SELECT = "select"                   # avatar selection screen
    LEVEL_SELECT = "level_select"  # pick any level (dev/testing jump, no intro)
    INTRO = "intro"                     # cinematic walk-into-cave before gameplay
    PLAY = "play"                       # normal gameplay
    PAUSE = "pause"                     # ESC during play: Resume / Quit to menu / Quit game
    STORE = "store"                     # the in-cave shop (opened with B); cave frozen
    DIED = "died"                       # crushed/caught, press R to retry level
    LEVEL_COMPLETE = "level_complete"   # cleared a level, press SPACE for next
    GAME_OVER = "game_over"             # out of lives, return to menu
    VICTORY = "victory"                 # cleared every level, return to menu

    def __init__(self, start_level=None):
        pygame.init()
        _build_key_map()                   # safe now: pygame's K_* constants exist
        self.log = setup_logging()         # per-session log (see setup_logging)
        self.log.info("session_start")
        # Audio: start the mixer and preload the intro clip. If the machine has
        # no audio device (headless server / dummy driver in the tests) or the
        # clip file is missing, we run silently - the game never crashes over
        # sound. Every playback call checks self.audio_ok / intro_clip_loaded.
        self.audio_ok = self._init_audio()
        self.intro_clip_loaded = False
        self.intro_clip_ms = 0                  # clip length in ms (0 if unknown)
        self._intro_music_fading = False      # one-shot guard for the fade-out
        if self.audio_ok:
            clip = Path(__file__).resolve().parent / INTRO_CLIP
            try:
                pygame.mixer.music.load(str(clip))
                self.intro_clip_loaded = True
            except (pygame.error, FileNotFoundError, RuntimeError):
                self.intro_clip_loaded = False
            # Measure the clip so the intro can last as long as it does (see
            # _advance_intro). Separate try/except so a length-reading hiccup
            # never stops the clip from PLAYING - it just falls back to 0.
            # (Sound() can read an mp3's length; mixer.music can't.)
            if self.intro_clip_loaded:
                try:
                    self.intro_clip_ms = int(round(
                        pygame.mixer.Sound(str(clip)).get_length() * 1000))
                except (pygame.error, RuntimeError):
                    self.intro_clip_ms = 0
        self.sfx = SfxBank(self.audio_ok)   # procedural SFX; empty bank if no audio
        # vsync keeps the loop smooth; SCALED lets pygame handle DPI scaling.
        # Try accelerated scaling+vsync; fall back to a plain window if the
        # driver doesn't support it (e.g. headless servers / some VMs).
        try:
            self.screen = pygame.display.set_mode((W, H), pygame.SCALED, vsync=1)
        except (pygame.error, RuntimeError):
            self.screen = pygame.display.set_mode((W, H))
        pygame.display.set_caption("Ogatu - a digging riddle")
        self.clock = pygame.time.Clock()

        # Fonts: SysFont falls back to a default if "consolas" is missing.
        self.font_big = pygame.font.SysFont("consolas", 30, bold=True)
        self.font = pygame.font.SysFont("consolas", 18, bold=True)
        self.font_sm = pygame.font.SysFont("consolas", 14)

        # Run-wide state.
        self.level_index = 0
        self.lives = START_LIVES
        self.score = 0          # banked score from completed levels

        # Per-frame timing accumulators. Each subsystem steps when its
        # accumulator crosses its threshold (see constants MOVE_REPEAT_MS etc).
        self.accum_move = 0
        self.accum_grav = 0
        self.accum_enemy = 0
        self.accum_hunter = 0
        self.accum_bomb = 0

        self.held_dir = None    # direction currently held down by the player
        self.mode = self.HOME
        self.intro_t = 0                # elapsed ms in the intro cutscene
        self.avatar = 0                 # chosen avatar index (0=Ranganna, 1=Avyan, 2=Avni)
        self.select_idx = 0             # cursor on the avatar-selection screen
        self.menu_idx = 0              # cursor on the HOME menu (0=Start Game, 1=Select)
        self.level_select_idx = 0     # cursor on the Level Select screen
        self.pause_idx = 0             # cursor on the PAUSE menu (0=Resume)
        self.store_idx = 0            # cursor on the STORE screen
        self._quit = False            # set True to end the main loop cleanly

        # Juice state: particle bursts, screen shake, and an offscreen surface
        # for the cave so it can shake independently of the HUD bar above it.
        self.particles = []                          # list of active particle dicts
        self.shake = 0                               # remaining shake time (ms)
        self._cave_surf = pygame.Surface((W, LEVEL_ROWS * TILE_SIZE))

        self.level = load_level(0)

        # Dev/testing shortcut: --level N on the command line jumps straight
        # into a level (no menu, no intro). See main.py.
        if start_level is not None and 0 <= start_level < len(LEVELS):
            self.start_at_level(start_level)

    # ---- level / game lifecycle -------------------------------------------
    def load_level(self, idx, reason="init"):
        """(Re)load a fresh copy of level `idx` and reset its timers.

        `reason` is logged with the load so a session log reads clearly: "init"
        (placeholder cave at launch), "new_game", "restart" (player pressed R),
        or "advance" (cleared a cave and moved to the next).
        """
        self.level = load_level(idx)
        self.level_index = idx
        self.accum_move = self.accum_grav = self.accum_enemy = self.accum_hunter = self.accum_bomb = 0
        self.particles = []                          # clear leftover particles
        self.shake = 0                               # reset shake on level change
        self.log.info("level_load idx=%d required=%d reason=%s",
                      idx, self.level.diamonds_required, reason)

    def start_new_game(self):
        """Begin a fresh game from the HOME 'Start Game' option.

        Resets lives + score, loads cave 1, and plays the intro cutscene. This
        is the only entry point into gameplay now - there is no 'press I'
        shortcut anymore.
        """
        self.lives = START_LIVES
        self.score = 0
        self.log.info("new_game avatar=%s lives=%d",
                      AVATARS[self.avatar]["name"], START_LIVES)
        self.load_level(0, reason="new_game")
        self._begin_intro()

    def start_at_level(self, idx):
        """Jump straight into level `idx` with NO intro.

        Used by the --level CLI flag and the Level Select menu - a dev/testing
        shortcut that skips the cave-1 intro and lands you in any level
        instantly. Lives/score reset as in start_new_game; from here the normal
        flow takes over (die out -> Game Over -> HOME, clear -> advance).
        """
        self.lives = START_LIVES
        self.score = 0
        self.log.info("new_game avatar=%s lives=%d",
                      AVATARS[self.avatar]["name"], START_LIVES)
        self.load_level(idx, reason="new_game")
        self.mode = self.PLAY

    # ---- audio ------------------------------------------------------------
    def _init_audio(self):
        """Start pygame's mixer so we can play the intro clip (and later SFX).

        pygame.init() usually starts the mixer already; if not, we init it
        explicitly. Returns True if audio is available, False otherwise. When
        False, every sound call is a guarded no-op so the game still runs.
        """
        if pygame.mixer.get_init() is not None:
            return True
        try:
            pygame.mixer.init()
            return True
        except pygame.error:
            return False

    def _play_intro_music(self):
        """Start the intro clip from the top. No-op if audio is off or the clip
        is missing. play() rewinds, so this is safe to call on every new game."""
        if not (self.audio_ok and self.intro_clip_loaded):
            return
        try:
            pygame.mixer.music.play()
        except pygame.error:
            pass

    def _stop_intro_music(self):
        """Stop the intro clip if it is playing. Safe any time (no-op if idle)."""
        if not self.audio_ok:
            return
        try:
            pygame.mixer.music.stop()
        except pygame.error:
            pass

    def _fadeout_intro_music(self, ms):
        """Fade the intro clip out over `ms` ms; a mild tail into the black hold."""
        if not self.audio_ok:
            return
        try:
            pygame.mixer.music.fadeout(ms)
        except pygame.error:
            pass

    def _begin_intro(self):
        """Start the cinematic walk-into-cave intro.

        Called only from start_new_game (the HOME 'Start Game' option), so the
        intro plays once per game start - NOT between levels or on death-retry.
        """
        self.intro_t = 0
        self.mode = self.INTRO
        self._intro_music_fading = False
        self._play_intro_music()

    def _advance_intro(self, dt):
        """Advance the intro timer; switch to gameplay when the cutscene ends.

        The intro lasts at least as long as its walk+enter+fade animation (and the
        backing clip, if longer). After the cutscene resolves it then holds on a
        pure BLACK screen for INTRO_BLACK_HOLD_MS - a deliberate beat before the
        cave appears - and only then starts gameplay. (The draw already clamps the
        fade to full black past the animation, so the hold is black silence, not a
        glitch.)
        A MILD fade-out (INTRO_MUSIC_FADE_MS) eases the clip's tail into that
        silence just before it finishes, so it doesn't cut dead.
        """
        self.intro_t += dt
        # Ease the clip's tail out with a MILD fade just before it finishes, so it
        # doesn't cut dead into the black hold. The once-flag (reset in
        # _begin_intro) stops it re-firing every frame.
        if (self.intro_clip_loaded and not self._intro_music_fading
                and self.intro_clip_ms > INTRO_MUSIC_FADE_MS
                and self.intro_t >= self.intro_clip_ms - INTRO_MUSIC_FADE_MS):
            self._fadeout_intro_music(INTRO_MUSIC_FADE_MS)
            self._intro_music_fading = True
        intro_end = max(INTRO_WALK_MS + INTRO_ENTER_MS + INTRO_FADE_MS,
                        self.intro_clip_ms) + INTRO_BLACK_HOLD_MS
        if self.intro_t >= intro_end:
            self.mode = self.PLAY
            self._stop_intro_music()

    def level_score(self):
        """Points earned in the CURRENT level (not yet banked to self.score)."""
        return (self.level.diamonds_collected * DIAMOND_SCORE
                + self.level.enemies_crushed * ENEMY_SCORE)

    def displayed_score(self):
        return self.score + self.level_score()

    # ---- the main loop -----------------------------------------------------
    async def run(self):
        # NOTE: this loop is `async` and yields once per frame (see the
        # `await asyncio.sleep(0)` below). On the desktop that yield is a
        # near-free no-op; in the browser (pygbag/WebAssembly build) it is
        # MANDATORY - it hands control back to the browser so the page stays
        # responsive and the canvas actually repaints. Same code, both targets.
        running = True
        while running:
            dt = self.clock.tick(FPS)          # ms elapsed since last frame
            running = self._handle_events()
            if self.mode == self.PLAY:
                self._update(dt)
            elif self.mode == self.INTRO:
                self._advance_intro(dt)
            else:
                # Keep particles + shake animating on overlay screens too
                # (dust settles after death, shake decays smoothly).
                self._update_particles(dt)
                self.shake = max(0, self.shake - dt)
            self._draw()
            # Hand the frame back to the event loop. Desktop: negligible.
            # Browser: this is what lets pygbag drive the game off requestAnimationFrame.
            await asyncio.sleep(0)
        self.log.info("session_end")
        pygame.quit()

    def _handle_events(self):
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                return False
            if ev.type == pygame.KEYDOWN:
                self._on_keydown(ev.key)
                if self._quit:                 # _on_keydown requested a clean exit
                    return False
            elif ev.type == pygame.KEYUP:
                self._on_keyup(ev.key)
        return True
    def _on_keydown(self, key):
        # M toggles SFX mute on ANY screen (per-session, resets each launch - the
        # same scope as the avatar choice). Handled first so it works during
        # play, menus, and overlays alike. The intro clip is on the music channel
        # and is unaffected; this mutes only the procedural SFX.
        if key == pygame.K_m:
            muted = self.sfx.toggle_mute()
            self.log.info("sfx_muted=%s", muted)
            return
        # ESC is context-sensitive: PAUSE during play, back out to the menu
        # from other in-game screens, and quit the app only from the HOME menu.
        if key == pygame.K_ESCAPE:
            if self.mode == self.HOME:
                self._quit = True                     # top-level: quit the app
            elif self.mode == self.PLAY:
                self.pause_idx = 0                    # cursor on Resume (safe default)
                self.mode = self.PAUSE
            elif self.mode == self.PAUSE:
                self.mode = self.PLAY                 # ESC toggles pause off (resume)
            elif self.mode == self.STORE:
                self.mode = self.PLAY                 # ESC closes the store -> resume
            else:
                self.mode = self.HOME                 # back out from SELECT/INTRO/overlays
                self._stop_intro_music()
            return

        # HOME menu: Up/Down to move the cursor, Enter/Space to pick an option.
        if self.mode == self.HOME:
            if key in (pygame.K_UP, pygame.K_w):
                self.menu_idx = (self.menu_idx - 1) % len(MENU_ITEMS)
                self.sfx.play("menu_move")
            elif key in (pygame.K_DOWN, pygame.K_s):
                self.menu_idx = (self.menu_idx + 1) % len(MENU_ITEMS)
                self.sfx.play("menu_move")
            elif key in (pygame.K_RETURN, pygame.K_SPACE):
                self.sfx.play("menu_confirm")
                if self.menu_idx == 0:              # START GAME
                    self.start_new_game()
                elif self.menu_idx == 1:            # SELECT CHARACTER
                    self.select_idx = self.avatar   # cursor starts on current pick
                    self.mode = self.SELECT
                else:                               # LEVEL SELECT
                    self.level_select_idx = 0
                    self.mode = self.LEVEL_SELECT
            return

        # Avatar selection: left/right to cycle, Enter/Space to confirm. The
        # choice is applied, then we return to the HOME menu - selecting a
        # character does NOT start the game (Start Game does).
        if self.mode == self.SELECT:
            if key in (pygame.K_LEFT, pygame.K_a):
                self.select_idx = (self.select_idx - 1) % len(AVATARS)
                self.sfx.play("menu_move")
            elif key in (pygame.K_RIGHT, pygame.K_d):
                self.select_idx = (self.select_idx + 1) % len(AVATARS)
                self.sfx.play("menu_move")
            elif key in (pygame.K_RETURN, pygame.K_SPACE):
                self.sfx.play("menu_confirm")
                self.avatar = self.select_idx
                self.menu_idx = 0     # cursor back on Start Game (the likely next step)
                self.mode = self.HOME
            return

        # Level Select: Up/Down to pick a level, Enter to jump straight into it
        # (no intro). ESC backs out to HOME via the generic ESC block above.
        if self.mode == self.LEVEL_SELECT:
            if key in (pygame.K_UP, pygame.K_w):
                self.level_select_idx = (self.level_select_idx - 1) % len(LEVELS)
                self.sfx.play("menu_move")
            elif key in (pygame.K_DOWN, pygame.K_s):
                self.level_select_idx = (self.level_select_idx + 1) % len(LEVELS)
                self.sfx.play("menu_move")
            elif key in (pygame.K_RETURN, pygame.K_SPACE):
                self.sfx.play("menu_confirm")
                self.start_at_level(self.level_select_idx)
            return

        # Intro: any key skips the cutscene after a short grace period (so a
        # held title-screen key doesn't instantly cancel it).
        if self.mode == self.INTRO:
            if self.intro_t >= INTRO_SKIP_GUARD_MS:
                self.mode = self.PLAY
                self._stop_intro_music()
            return

        # Pause menu: Up/Down to move the cursor, Enter/Space to pick (ESC also
        # resumes). Never starts/restarts a level - it only leaves PLAY.
        if self.mode == self.PAUSE:
            if key in (pygame.K_UP, pygame.K_w):
                self.pause_idx = (self.pause_idx - 1) % len(PAUSE_ITEMS)
                self.sfx.play("menu_move")
            elif key in (pygame.K_DOWN, pygame.K_s):
                self.pause_idx = (self.pause_idx + 1) % len(PAUSE_ITEMS)
                self.sfx.play("menu_move")
            elif key in (pygame.K_RETURN, pygame.K_SPACE):
                self.sfx.play("menu_confirm")
                choice = PAUSE_ITEMS[self.pause_idx]
                if choice == "RESUME":
                    self.mode = self.PLAY
                elif choice == "QUIT TO MENU":
                    self.mode = self.HOME
                else:                                 # QUIT GAME
                    self._quit = True
            return

        # Store: Up/Down browse, Enter/Space buys the selected item, B closes
        # (ESC also closes, handled above). The cave is frozen while shopping.
        if self.mode == self.STORE:
            if key in (pygame.K_UP, pygame.K_w):
                self.store_idx = (self.store_idx - 1) % len(STORE_ITEMS)
                self.sfx.play("menu_move")
            elif key in (pygame.K_DOWN, pygame.K_s):
                self.store_idx = (self.store_idx + 1) % len(STORE_ITEMS)
                self.sfx.play("menu_move")
            elif key in (pygame.K_RETURN, pygame.K_SPACE):
                self._buy_selected()
            elif key == pygame.K_b:
                self.mode = self.PLAY                 # B toggles the store closed
            return

        # Overlay screens each have their own dismissal key.
        if self.mode == self.DIED:
            if key == pygame.K_r:
                self.load_level(self.level_index, reason="restart")
                self.mode = self.PLAY
            return
        if self.mode == self.LEVEL_COMPLETE:
            if key in (pygame.K_SPACE, pygame.K_RETURN):
                nxt = self.level_index + 1
                if nxt >= len(LEVELS):
                    self.score += self.level_score()
                    self.mode = self.VICTORY
                else:
                    self.load_level(nxt, reason="advance")
                    self.mode = self.PLAY
            return
        if self.mode in (self.GAME_OVER, self.VICTORY):
            if key in (pygame.K_SPACE, pygame.K_RETURN):
                self.mode = self.HOME
            return

        # Normal play: a direction key moves immediately (feels responsive)
        # and then keeps moving while held (handled in _update).
        direction = KEY_TO_DIR.get(key)
        if direction:
            self.held_dir = direction
            self.accum_move = MOVE_REPEAT_MS - MOVE_INITIAL_MS  # negative: delay first repeat
            self._player_move(direction)
        elif key == pygame.K_r:
            # Manual restart of the current level.
            self.load_level(self.level_index, reason="restart")
        elif key == pygame.K_SPACE:
            self._place_bomb()                        # drop dynamite on your tile
        elif key == pygame.K_b:
            self.store_idx = 0                        # open the store (cave freezes)
            self.mode = self.STORE
            self.sfx.play("menu_move")

    def _on_keyup(self, key):
        direction = KEY_TO_DIR.get(key)
        if direction and self.held_dir == direction:
            self.held_dir = None

    # ---- per-frame simulation (only while playing) ------------------------
    def _update(self, dt):
        # 1) Continuous player movement while a direction is held.
        if self.held_dir:
            self.accum_move += dt
            while self.accum_move >= MOVE_REPEAT_MS:
                self.accum_move -= MOVE_REPEAT_MS
                self._player_move(self.held_dir)
                if self.mode != self.PLAY:
                    return

        # 2) Gravity: boulders and diamonds fall.
        self.accum_grav += dt
        while self.accum_grav >= GRAV_MS:
            self.accum_grav -= GRAV_MS
            crushed_before = self.level.enemies_crushed
            self.level.step_gravity()
            # An enemy explosion mid-gravity triggers a medium shake.
            if self.level.enemies_crushed > crushed_before:
                self.shake = max(self.shake, SHAKE_ON_EXPLODE)
                self.sfx.play("explosion")
                self.log.info("enemy_crushed level=%d total=%d",
                              self.level_index + 1, self.level.enemies_crushed)
            self._after_step()
            if self.mode != self.PLAY:
                return

        # 2.5) Dynamite: planted bombs tick their fuses and detonate on their
        # own timer (independent of gravity so the fuse feel is tunable).
        self.accum_bomb += dt
        while self.accum_bomb >= BOMB_MS:
            self.accum_bomb -= BOMB_MS
            crushed_before = self.level.enemies_crushed
            centres = self.level.step_bombs()
            if centres:
                self.shake = max(self.shake, SHAKE_ON_EXPLODE)
                self.sfx.play("explosion")
                for (br, bc) in centres:
                    self._spawn_blast(br, bc)
                self.log.info("bomb_detonated level=%d count=%d enemies_killed=%d",
                              self.level_index + 1, len(centres),
                              self.level.enemies_crushed - crushed_before)
            self._after_step()
            if self.mode != self.PLAY:
                return

        # 3) Enemies: fireflies patrol.
        self.accum_enemy += dt
        while self.accum_enemy >= ENEMY_MS:
            self.accum_enemy -= ENEMY_MS
            self.level.step_enemies()
            self._after_step()
            if self.mode != self.PLAY:
                return

        # 4) Hunters: chase the player along open tunnels (their own slower
        # timer so they stay outrunnable; one BFS field is shared by all).
        self.accum_hunter += dt
        while self.accum_hunter >= HUNTER_MS:
            self.accum_hunter -= HUNTER_MS
            self.level.step_hunters()
            self._after_step()
            if self.mode != self.PLAY:
                return

        # 5) Juice: update particles and decay screen shake every frame.
        self._update_particles(dt)
        self.shake = max(0, self.shake - dt)

    def _after_step(self):
        """Translate the engine's level outcome into a UI mode change."""
        if self.level.status == LOST:
            self.lives -= 1
            self.shake = max(self.shake, SHAKE_ON_CRUSH)   # big jolt on death
            self.sfx.play("crush")
            self.log.info("death level=%d lives_left=%d",
                          self.level_index + 1, max(self.lives, 0))
            if self.lives <= 0:
                self.mode = self.GAME_OVER
                self.sfx.play("game_over")
                self.log.info("game_over final_score=%d",
                              self.displayed_score())
            else:
                self.mode = self.DIED
        elif self.level.status == WON:
            lvl = self.level
            self.log.info("level_complete level=%d diamonds=%d/%d score=%d",
                          self.level_index + 1, lvl.diamonds_collected,
                          lvl.diamonds_required, self.displayed_score())
            if self.level_index >= len(LEVELS) - 1:
                self.score += self.level_score()
                self.mode = self.VICTORY
                self.sfx.play("victory")
                self.log.info("victory final_score=%d", self.score)
            else:
                self.mode = self.LEVEL_COMPLETE
                self.sfx.play("level_complete")

    # ---- juice helpers ----------------------------------------------------
    def _player_move(self, direction):
        """Move the player and spawn dig-dust if a dirt tile was dug.

        This wraps engine.move_player so the renderer can detect a dig (dirt
        cell in front of the player) and react with a particle burst without
        the engine knowing anything about particles.
        """
        r, c = self.level.player
        dr, dc = direction
        tr, tc = r + dr, c + dc
        was_dirt = (self.level.in_bounds(tr, tc)
                    and self.level.cell(tr, tc) == DIRT)
        gems_before = self.level.diamonds_collected
        self.level.move_player(direction)
        if was_dirt:
            self._spawn_dig_dust(tr, tc)
            self.sfx.play("dig")
        # A diamond pickup brightens with a blip; hitting the required count
        # unlocks the exit with a chime (fires once - gems only tick up by 1).
        if self.level.diamonds_collected > gems_before:
            self.sfx.play("collect")
            if self.level.diamonds_collected == self.level.diamonds_required:
                self.sfx.play("exit_unlock")
        self._after_step()

    def _place_bomb(self):
        """Plant a bomb on the player's tile (engine guards inventory + legality).
        A soft thunk on success; a quiet blip if you're out of bombs or blocked."""
        if self.level.place_bomb():
            self.sfx.play("dig")
            self.log.info("bomb_planted level=%d remaining=%d",
                          self.level_index + 1, self.level.bombs_inventory)
        else:
            self.sfx.play("menu_move")

    def _buy_selected(self):
        """Buy the highlighted store item with the player's diamond wallet."""
        item = STORE_ITEMS[self.store_idx]
        bought = self.level.buy_bomb() if item["action"] == "bomb" else False
        if bought:
            self.sfx.play("menu_confirm")
            self.log.info("store_buy item=%s wallet=%d bombs=%d",
                          item["name"], self.level.wallet(),
                          self.level.bombs_inventory)
        else:
            self.sfx.play("menu_move")            # can't afford it / no-op

    def _spawn_blast(self, grid_r, grid_c):
        """Burst bright orange/red sparks outward from a bomb detonation cell."""
        cx = grid_c * TILE_SIZE + TILE_SIZE // 2
        cy = grid_r * TILE_SIZE + TILE_SIZE // 2
        for _ in range(18):
            angle = random.uniform(0, math.tau)
            speed = random.uniform(0.06, 0.22)            # pixels per ms
            self.particles.append({
                "x": cx + random.uniform(-4, 4),
                "y": cy + random.uniform(-4, 4),
                "vx": math.cos(angle) * speed,
                "vy": math.sin(angle) * speed,
                "life": random.uniform(180, 420),
                "max": 420,
                "color": random.choice([(255, 176, 60), (255, 90, 40), (255, 230, 120)]),
                "size": random.uniform(2, 5),
            })

    def _spawn_dig_dust(self, grid_r, grid_c):
        """Burst a handful of brown dust particles outward from a dug cell."""
        cx = grid_c * TILE_SIZE + TILE_SIZE // 2
        cy = grid_r * TILE_SIZE + TILE_SIZE // 2
        for _ in range(6):
            # math.tau is 2*pi (one full turn) - a uniform random direction.
            angle = random.uniform(0, math.tau)
            speed = random.uniform(0.03, 0.09)            # pixels per ms
            self.particles.append({
                "x": cx + random.uniform(-3, 3),
                "y": cy + random.uniform(-3, 3),
                "vx": math.cos(angle) * speed,
                "vy": math.sin(angle) * speed,
                "life": random.uniform(120, 260),         # ms before fading out
                "max": 260,
                "color": (150, 96, 58),                   # dirt brown
                "size": random.uniform(2, 4),
            })

    def _update_particles(self, dt):
        """Advance particles, apply mild gravity, and cull expired ones."""
        alive = []
        for p in self.particles:
            p["life"] -= dt
            if p["life"] <= 0:
                continue
            p["x"] += p["vx"] * dt
            p["y"] += p["vy"] * dt
            p["vy"] += 0.0008 * dt                        # particles drift down
            alive.append(p)
        self.particles = alive

    def _draw_particles(self, surf):
        """Draw particles onto the cave surface, fading as they expire."""
        for p in self.particles:
            fade = max(0.0, p["life"] / p["max"])         # 1.0 -> 0.0
            col = (int(p["color"][0] * fade),
                   int(p["color"][1] * fade),
                   int(p["color"][2] * fade))
            size = max(1, int(p["size"] * fade))
            pygame.draw.circle(surf, col, (int(p["x"]), int(p["y"])), size)

    def _shake_offset(self):
        """Random (x, y) pixel displacement whose magnitude decays with shake."""
        if self.shake <= 0:
            return 0, 0
        mag = min(self.shake / 40.0, 11.0)               # cap at 11 pixels
        return (random.uniform(-mag, mag), random.uniform(-mag, mag))

    @staticmethod
    def _lerp_color(c1, c2, t):
        """Linear interpolation between two (R,G,B) colors. t is clamped 0..1."""
        t = max(0.0, min(1.0, t))
        return (int(c1[0] + (c2[0] - c1[0]) * t),
                int(c1[1] + (c2[1] - c1[1]) * t),
                int(c1[2] + (c2[2] - c1[2]) * t))

    # ---- rendering ---------------------------------------------------------
    def _draw(self):
        # Intro cutscene: draw the walk-into-cave scene alone (no HUD, no cave).
        if self.mode == self.INTRO:
            self._draw_intro()
            pygame.display.flip()
            return
        # HOME menu: a full-screen menu (no HUD, no cave), like SELECT/INTRO.
        if self.mode == self.HOME:
            self._draw_home()
            pygame.display.flip()
            return
        # Avatar selection: draw the character-picker screen alone.
        if self.mode == self.SELECT:
            self._draw_select()
            pygame.display.flip()
            return
        # Level Select: a full-screen list of levels (no HUD, no cave).
        if self.mode == self.LEVEL_SELECT:
            self._draw_level_select()
            pygame.display.flip()
            return
        scr = self.screen
        scr.fill(COL_BG)

        self._draw_hud()

        # Render the cave to an offscreen surface so we can apply screen-shake
        # (a blit offset) without jiggling the HUD bar above it.
        cave = self._cave_surf
        cave.fill(COL_BG)
        lvl = self.level
        for r in range(lvl.rows):
            for c in range(lvl.cols):
                rect = pygame.Rect(c * TILE_SIZE, r * TILE_SIZE,
                                   TILE_SIZE, TILE_SIZE)
                self._draw_tile(cave, rect, r, c, lvl)

        # Entities and particles float on top of their (empty) cells.
        self._draw_player(cave, lvl.player, 0)
        for e in lvl.enemies:
            self._draw_enemy(cave, (e[0], e[1]), 0, e[3])
        self._draw_particles(cave)

        # Blit the cave onto the screen at the shake-offset position.
        sx, sy = self._shake_offset()
        scr.blit(cave, (sx, HUD_HEIGHT + sy))

        if self.mode != self.PLAY:
            self._draw_overlay()

        pygame.display.flip()

    def _draw_hud(self):
        scr = self.screen
        pygame.draw.rect(scr, COL_HUD, (0, 0, W, HUD_HEIGHT))
        pygame.draw.line(scr, COL_HUD_LINE, (0, HUD_HEIGHT), (W, HUD_HEIGHT), 2)

        lvl = self.level
        diamonds_txt = f"DIAMONDS {lvl.diamonds_collected}/{lvl.diamonds_required}"
        bombs_txt = f"BOMBS {lvl.bombs_inventory}"
        lives_txt = f"LIVES {max(self.lives, 0)}"
        level_txt = f"LEVEL {self.level_index + 1}/{len(LEVELS)}"
        score_txt = f"SCORE {self.displayed_score()}"

        # Diamond counter turns green once the exit is unlocked.
        d_color = COL_GOOD if lvl.exit_active() else COL_DIAMOND
        self._hud_text(diamonds_txt, 12, d_color, self.font)
        self._hud_text(bombs_txt, 178, COL_BOMB_SPARK, self.font)
        self._hud_text(score_txt, 270, COL_TEXT, self.font)
        self._hud_text(lives_txt, 392, COL_TEXT, self.font)
        self._hud_text(level_txt, 482, COL_TEXT_DIM, self.font)
        right_txt = "[muted] (M)" if self.sfx.muted else "B store"
        self._hud_text(right_txt, W - 86,
                       COL_BAD if self.sfx.muted else COL_TEXT_DIM, self.font_sm)

    def _hud_text(self, text, x, color, font):
        surf = font.render(text, True, color)
        self.screen.blit(surf, (x, (HUD_HEIGHT - surf.get_height()) // 2))

    def _draw_tile(self, scr, rect, r, c, lvl):
        ch = lvl.cell(r, c)
        if ch == WALL:
            scr.fill(COL_WALL, rect)
            # a subtle inset to give the steel wall some depth
            inset = rect.inflate(-6, -6)
            pygame.draw.rect(scr, (60, 60, 74), inset, border_radius=3)
        elif ch == DIRT:
            scr.fill(COL_DIRT, rect)
            # scatter a few darker specks for a cheap dirt texture
            pygame.draw.rect(scr, (104, 64, 40), rect.inflate(-10, -10),
                             border_radius=2)
        elif ch == EMPTY:
            scr.fill(COL_EMPTY, rect)
        elif ch == BOULDER:
            scr.fill(COL_EMPTY, rect)
            # Falling boulders get a warm danger tint so the player can read
            # which rocks are in motion (and thus lethal on landing). This uses
            # the engine's new self.falling set - pure visual, no rule change.
            if (r, c) in lvl.falling:
                self._circle(scr, rect, (210, 160, 95), (255, 130, 50))
            else:
                self._circle(scr, rect, COL_BOULDER, (96, 96, 108))
        elif ch == DIAMOND:
            scr.fill(COL_EMPTY, rect)
            # Gentle glow pulse: gems breathe between muted cyan and bright
            # cyan-white. Narrower range than v1 (visible without being flashy).
            pulse = 0.5 + 0.5 * math.sin(pygame.time.get_ticks() / 200)
            glow = self._lerp_color((65, 185, 200), (180, 250, 255), pulse)
            self._diamond(scr, rect, glow)
        elif ch == EXIT:
            scr.fill(COL_EMPTY, rect)
            color = COL_EXIT_ON if lvl.exit_active() else COL_EXIT_OFF
            door = rect.inflate(-8, -6)
            pygame.draw.rect(scr, color, door, border_radius=3)
            # a little knob so it reads as a door
            pygame.draw.circle(scr, COL_BG, (door.right - 5, door.centery), 2)
        elif ch == BOMB:
            scr.fill(COL_EMPTY, rect)
            self._draw_bomb(scr, rect, lvl.bombs.get((r, c), 0))

    def _circle(self, scr, rect, fill, outline):
        pygame.draw.circle(scr, fill, rect.center, TILE_SIZE // 2 - 4)
        pygame.draw.circle(scr, outline, rect.center, TILE_SIZE // 2 - 4, 2)

    def _diamond(self, scr, rect, color):
        cx, cy = rect.center
        s = TILE_SIZE // 2 - 5
        points = [(cx, cy - s), (cx + s, cy), (cx, cy + s), (cx - s, cy)]
        pygame.draw.polygon(scr, color, points)
        pygame.draw.polygon(scr, (220, 250, 255), points, 1)

    def _draw_bomb(self, scr, rect, fuse):
        """A dark round bomb with a fuse spark that flashes faster - and toward
        red - as the fuse runs out, so the urgency to flee reads at a glance."""
        cx, cy = rect.center
        rad = TILE_SIZE // 2 - 6
        # Blink speeds up as the fuse shrinks (fuse counts down toward 0).
        speed = 120 + 90 * max(fuse, 0)
        blink = 0.5 + 0.5 * math.sin(pygame.time.get_ticks() / max(speed, 60))
        pygame.draw.circle(scr, COL_BOMB, (cx, cy), rad)
        pygame.draw.circle(scr, (90, 88, 104), (cx, cy), rad, 2)
        # A short fuse stub poking out the top.
        pygame.draw.line(scr, (120, 100, 70), (cx, cy - rad),
                         (cx + 4, cy - rad - 5), 2)
        # The spark: pulses orange->red and grows as detonation nears.
        spark = self._lerp_color(COL_BOMB_SPARK, (255, 40, 30), blink)
        sr = 2 + int(2 * blink)
        pygame.draw.circle(scr, spark, (cx + 4, cy - rad - 6), sr)

    def _draw_avatar(self, scr, cx, cy, radius, avatar_id, alpha=1.0):
        """Draw any avatar at (cx, cy) with the given pixel radius and fade.

        alpha < 1.0 lerps every colour toward COL_BG — used by the intro
        shrink/fade. Works at any size: gameplay (~14px) or select (~42px).
        """
        av = AVATARS[avatar_id]
        body = self._lerp_color(COL_BG, av["body"], alpha)
        rim = self._lerp_color(COL_BG, av["rim"], alpha)
        eye = self._lerp_color(COL_BG, av["eye"], alpha)

        # Pigtails: two small circles behind the body, peeking out on the sides.
        if av["accessory"] == "pigtails":
            acc = self._lerp_color(COL_BG, av["acc_col"], alpha)
            pr = max(2, int(radius * 0.38))
            off = int(radius * 0.72)
            py = cy - int(radius * 0.22)
            pygame.draw.circle(scr, acc, (cx - off, py), pr)
            pygame.draw.circle(scr, acc, (cx + off, py), pr)

        # Cap dome: a circle behind the body, shifted up so only the top
        # crescent shows above the head (the body covers the rest).
        if av["accessory"] == "cap":
            acc = self._lerp_color(COL_BG, av["acc_col"], alpha)
            cap_r = int(radius * 0.92)
            cap_cy = cy - int(radius * 0.6)
            pygame.draw.circle(scr, acc, (cx, cap_cy), cap_r)

        # Body circle + outline.
        pygame.draw.circle(scr, body, (cx, cy), radius)
        pygame.draw.circle(scr, rim, (cx, cy), radius, 2)

        # Eyes (only when large enough to see them).
        if radius > 6:
            er = max(1, int(radius * 0.16))
            ex = int(radius * 0.35)
            ey = cy - int(radius * 0.1)
            pygame.draw.circle(scr, eye, (cx - ex, ey), er)
            pygame.draw.circle(scr, eye, (cx + ex, ey), er)

    def _draw_player(self, scr, pos, oy):
        """Draw the selected avatar at the player's grid position."""
        r, c = pos
        cx = c * TILE_SIZE + TILE_SIZE // 2
        cy = oy + r * TILE_SIZE + TILE_SIZE // 2
        self._draw_avatar(scr, cx, cy, TILE_SIZE // 2 - 4, self.avatar)

    def _draw_enemy(self, scr, pos, oy, kind):
        """Draw a mobile enemy by KIND, each with a distinct silhouette so they
        read apart at a glance (never by colour alone - matters for colour-blind
        players): firefly = orange orb, butterfly = purple wings, hunter =
        crimson danger-star."""
        r, c = pos
        rect = pygame.Rect(c * TILE_SIZE, oy + r * TILE_SIZE, TILE_SIZE, TILE_SIZE)
        cx, cy = rect.center
        rad = TILE_SIZE // 2 - 4
        if kind == BUTTERFLY:
            # Two purple wings (left + right) with a magenta rim and a dark
            # body down the middle - reads as a butterfly, not a coloured blob.
            wing_w, wing_h = rad - 1, 2 * rad
            for sx in (-1, 1):
                wr = pygame.Rect(0, 0, wing_w, wing_h)
                wr.center = (cx + sx * (wing_w // 2 + 1), cy)
                pygame.draw.ellipse(scr, COL_BUTTERFLY, wr)
                pygame.draw.ellipse(scr, (240, 170, 255), wr, 2)   # magenta rim
            pygame.draw.rect(scr, (60, 30, 70),
                             pygame.Rect(cx - 1, cy - rad + 3, 2, 2 * rad - 6))
        elif kind == HUNTER:
            # Hunter: an angular crimson "danger star" - a spiky silhouette that
            # reads as a threat and stays distinct from the firefly's round orb
            # and the butterfly's wings (shape, not just colour).
            R = rad + 1
            ri = max(2, R * 2 // 5)
            pts = [
                (cx, cy - R), (cx + ri, cy - ri),
                (cx + R, cy), (cx + ri, cy + ri),
                (cx, cy + R), (cx - ri, cy + ri),
                (cx - R, cy), (cx - ri, cy - ri),
            ]
            pygame.draw.polygon(scr, COL_HUNTER, pts)
            pygame.draw.polygon(scr, (90, 0, 8), pts, 2)           # dark crimson rim
            pygame.draw.circle(scr, (255, 220, 150), (cx, cy), 3)  # menacing hot eye
        else:
            # Firefly: glowing orange orb with a dark ring and a hot core.
            pygame.draw.circle(scr, COL_FIREFLY, rect.center, rad)
            pygame.draw.circle(scr, (120, 30, 0), rect.center, rad, 2)
            pygame.draw.circle(scr, (255, 220, 120), rect.center, 3)

    def _draw_intro(self):
        """Render the cinematic walk-into-cave intro.

        The chosen explorer walks from the left toward a dark cave mouth
        carved into a cliff on the right. They shrink and fade as they enter,
        then the screen fades to black before gameplay begins. Pure renderer -
        no engine state is touched.
        """
        scr = self.screen
        t = self.intro_t

        # --- Scene geometry ---
        ground_y = int(H * 0.70)               # where the dirt ground begins
        cliff_x = int(W * 0.56)                # left edge of the rock cliff
        cave_cx = int(W * 0.74)                # horizontal center of the cave mouth
        cave_top = ground_y - 140              # top of the cave opening
        cave_w = 84                            # width of the cave opening

        # --- Dark night sky ---
        scr.fill((14, 12, 22))

        # Twinkling stars (fixed positions via a seeded RNG so they don't jitter;
        # only their brightness changes over time).
        star_rng = random.Random(12345)
        for _ in range(30):
            sx = star_rng.randint(0, cliff_x - 8)
            sy = star_rng.randint(10, ground_y - 30)
            twinkle = 0.4 + 0.6 * math.sin(t / 280 + sx * 0.1 + sy * 0.07)
            b = int(90 + 130 * max(0.0, twinkle))
            pygame.draw.circle(scr, (b, b, b), (sx, sy), 1)

        # --- Ground ---
        pygame.draw.rect(scr, COL_DIRT, (0, ground_y, W, H - ground_y))
        pygame.draw.rect(scr, (104, 64, 40), (0, ground_y, W, 3))  # top highlight

        # --- Rocky cliff on the right ---
        pygame.draw.rect(scr, COL_WALL, (cliff_x, 0, W - cliff_x, H))
        # Cliff texture: scattered darker blocks for a rough-rock feel.
        tex_rng = random.Random(999)
        for ry in range(0, H, 28):
            for rx in range(cliff_x, W, 38):
                if tex_rng.random() > 0.45:
                    bx = rx + tex_rng.randint(-4, 4)
                    by = ry + tex_rng.randint(-4, 4)
                    pygame.draw.rect(scr, (60, 60, 74),
                                     (bx, by, 32, 24), border_radius=2)

        # Cave mouth: a dark rounded arch carved into the cliff face.
        cave_rect = pygame.Rect(cave_cx - cave_w // 2, cave_top,
                                cave_w, ground_y - cave_top + 8)
        pygame.draw.rect(scr, (6, 4, 10), cave_rect,
                         border_top_left_radius=42, border_top_right_radius=42)
        pygame.draw.rect(scr, (3, 2, 5), cave_rect.inflate(-10, -8),
                         border_top_left_radius=36, border_top_right_radius=36)

        # --- The explorer walking into the cave ---
        if t < INTRO_WALK_MS + INTRO_ENTER_MS:
            start_x = 50
            end_x = cave_cx
            if t < INTRO_WALK_MS:
                # Phase 1: walk from the left edge to the cave mouth.
                walk_p = t / INTRO_WALK_MS
                px = start_x + (end_x - start_x) * walk_p
                bob = math.sin(t / 75) * 4               # footsteps bob
                scale = 1.0
                alpha = 1.0
            else:
                # Phase 2: entering - shrink + fade as he steps into the dark.
                enter_p = (t - INTRO_WALK_MS) / INTRO_ENTER_MS
                px = end_x                                # standing at the mouth
                bob = 0
                scale = 1.0 - 0.65 * enter_p              # shrink to ~35%
                alpha = 1.0 - enter_p                     # fade to invisible

            py = ground_y - TILE_SIZE // 2 + bob
            radius = max(1, int((TILE_SIZE // 2 - 4) * scale))
            self._draw_avatar(scr, int(px), int(py), radius,
                              self.avatar, alpha)

        # --- Fade to black ---
        if t > INTRO_WALK_MS + INTRO_ENTER_MS:
            fade_p = min((t - INTRO_WALK_MS - INTRO_ENTER_MS) / INTRO_FADE_MS, 1.0)
            veil = pygame.Surface((W, H))
            veil.fill((0, 0, 0))
            veil.set_alpha(int(255 * fade_p))
            scr.blit(veil, (0, 0))

    def _draw_select(self):
        """Render the avatar-selection screen.

        Three characters are shown side by side. The highlighted one is drawn
        full-size with a green ring and its name; the others are dimmed and
        smaller. Left/Right cycles the cursor (handled in _on_keydown).
        """
        scr = self.screen
        scr.fill(COL_BG)

        self._center("CHOOSE YOUR EXPLORER", self.font_big, COL_PLAYER, -140)

        big_r = 42                                   # avatar size on this screen
        spacing = W // (len(AVATARS) + 1)            # evenly spaced across the width
        cy = H // 2 - 10

        for i, av in enumerate(AVATARS):
            cx = spacing * (i + 1)
            selected = (i == self.select_idx)

            if selected:
                # Green highlight ring + full-brightness avatar.
                pygame.draw.circle(scr, COL_GOOD, (cx, cy), big_r + 12, 3)
                self._draw_avatar(scr, cx, cy, big_r, i)
                name = self.font.render(av["name"], True, COL_GOOD)
            else:
                # Dimmed, slightly smaller.
                self._draw_avatar(scr, cx, cy, int(big_r * 0.8), i, 0.35)
                name = self.font_sm.render(av["name"], True, COL_TEXT_DIM)

            scr.blit(name, (cx - name.get_width() // 2, cy + big_r + 22))

        # Pulsing instruction line.
        pulse = 0.5 + 0.5 * math.sin(pygame.time.get_ticks() / 350)
        glow = self._lerp_color(COL_TEXT_DIM, COL_GOOD, pulse)
        self._center("<- ->  choose      SPACE  confirm", self.font, glow, 120)

    def _draw_home(self):
        """Render the main menu: title + Start Game / Select Character.

        The landing screen on launch and the screen every game returns to when
        it ends. Up/Down moves the cursor, Enter/Space picks (see _on_keydown).
        The currently-selected explorer is previewed so the player knows who
        they'll control before hitting Start Game.
        """
        scr = self.screen
        scr.fill(COL_BG)

        # --- Title block ---
        self._center("OGATU", self.font_big, COL_PLAYER, -150)
        self._center("Dig - Collect diamonds - Drop rocks on fireflies",
                     self.font, COL_TEXT, -118)

        # --- Selected-explorer preview ---
        # A small avatar above its name: makes the Select Character choice
        # visible right on the menu (and shows the friendly Ranganna default
        # before the player ever opens the picker).
        av_cy = H // 2 - 48
        self._draw_avatar(scr, W // 2, av_cy, 20, self.avatar)
        av = AVATARS[self.avatar]
        name_surf = self.font.render(f"playing as  {av['name']}", True, COL_TEXT_DIM)
        scr.blit(name_surf,
                 (W // 2 - name_surf.get_width() // 2, av_cy + 28))

        # --- Menu items ---
        # Each item on its own line. The highlighted one is bright green with a
        # leading arrow; the rest are dimmed. MENU_ITEMS index 0 = Start Game.
        for i, label in enumerate(MENU_ITEMS):
            y_off = 38 + i * 36
            if i == self.menu_idx:
                txt = self.font.render(f"> {label}", True, COL_GOOD)
            else:
                txt = self.font.render(label, True, COL_TEXT_DIM)
            scr.blit(txt, (W // 2 - txt.get_width() // 2,
                           H // 2 + y_off - txt.get_height() // 2))

        # --- Controls hint ---
        self._center("Up/Down choose   Enter select   ESC quit",
                     self.font_sm, COL_TEXT_DIM, 130)

    def _draw_level_select(self):
        """Render the Level Select screen: a list of every level.

        A dev/player convenience - pick any cave and drop straight into it
        (no intro). Up/Down moves the cursor (wraps), Enter plays, ESC backs
        out to HOME. Lets you test or replay any level without playing through.
        """
        scr = self.screen
        scr.fill(COL_BG)
        self._center("SELECT LEVEL", self.font_big, COL_PLAYER, -150)
        # One row per level, named via LEVEL_NAMES; the highlighted one is
        # bright green with a leading arrow, the rest dimmed.
        for i in range(len(LEVELS)):
            name = LEVEL_NAMES[i] if i < len(LEVEL_NAMES) else f"Level {i + 1}"
            y_off = -60 + i * 30
            label = f"{i + 1}. {name}"
            if i == self.level_select_idx:
                txt = self.font.render(f"> {label}", True, COL_GOOD)
            else:
                txt = self.font.render(label, True, COL_TEXT_DIM)
            scr.blit(txt, (W // 2 - txt.get_width() // 2,
                           H // 2 + y_off - txt.get_height() // 2))
        self._center("Up/Down choose   Enter play   ESC back",
                     self.font_sm, COL_TEXT_DIM, 150)

    def _draw_overlay(self):
        """Dim the screen and show a centred message for the current overlay.

        Called only for the in-game / end-game overlays (DIED, LEVEL_COMPLETE,
        GAME_OVER, VICTORY). The HOME menu is a full screen of its own
        (_draw_home) and never reaches here.
        """
        scr = self.screen
        veil = pygame.Surface((W, H), pygame.SRCALPHA)
        veil.fill((0, 0, 0, 170))
        scr.blit(veil, (0, 0))

        if self.mode == self.PAUSE:
            self._center("PAUSED", self.font_big, COL_TEXT, -70)
            for i, label in enumerate(PAUSE_ITEMS):
                y_off = -8 + i * 34
                if i == self.pause_idx:
                    txt = self.font.render(f"> {label}", True, COL_GOOD)
                else:
                    txt = self.font.render(label, True, COL_TEXT_DIM)
                self.screen.blit(txt, (W // 2 - txt.get_width() // 2,
                                       H // 2 + y_off - txt.get_height() // 2))
            self._center("ESC resume   Up/Down choose   Enter select",
                         self.font_sm, COL_TEXT_DIM, 90)
        elif self.mode == self.DIED:
            self._center("CRUSHED!", self.font_big, COL_BAD, -20)
            self._center("press R to retry the level", self.font, COL_TEXT, 20)
        elif self.mode == self.LEVEL_COMPLETE:
            self._center("LEVEL COMPLETE", self.font_big, COL_GOOD, -20)
            self._center(f"score {self.displayed_score()}",
                         self.font, COL_TEXT, 10)
            self._center("press SPACE for the next cave",
                         self.font, COL_TEXT_DIM, 40)
        elif self.mode == self.GAME_OVER:
            self._center("GAME OVER", self.font_big, COL_BAD, -20)
            self._center(f"final score {self.displayed_score()}",
                         self.font, COL_TEXT, 10)
            self._center("press SPACE to return to menu",
                         self.font, COL_TEXT_DIM, 40)
        elif self.mode == self.VICTORY:
            self._center("YOU WIN!", self.font_big, COL_GOOD, -30)
            self._center(f"final score {self.displayed_score()}",
                         self.font, COL_TEXT, 10)
            self._center("all caves cleared - press SPACE to return to menu",
                         self.font_sm, COL_TEXT_DIM, 40)
        elif self.mode == self.STORE:
            self._draw_store()

    def _draw_store(self):
        """The in-cave store (opened with B). Lists buyable items with prices;
        shows the diamond wallet and current bomb count. Up/Down + Enter buy.
        Future items just append to STORE_ITEMS and render here for free."""
        lvl = self.level
        wallet = lvl.wallet()
        self._center("STORE", self.font_big, COL_DIAMOND, -120)
        self._center(f"wallet  {wallet} diamonds        bombs  {lvl.bombs_inventory}",
                     self.font, COL_TEXT, -82)
        for i, item in enumerate(STORE_ITEMS):
            afford = wallet >= item["cost"]
            y_off = -36 + i * 52
            if i == self.store_idx:
                head_col = COL_GOOD if afford else COL_BAD
                prefix = "> "
            else:
                head_col = COL_TEXT_DIM
                prefix = "  "
            self._center(f"{prefix}{item['name']}    {item['cost']} diamonds",
                         self.font, head_col, y_off)
            self._center(item["blurb"], self.font_sm, COL_TEXT_DIM, y_off + 22)
        self._center("Up/Down choose    Enter buy    B / ESC close",
                     self.font_sm, COL_TEXT_DIM, 120)

    def _center(self, text, font, color, y_offset):
        surf = font.render(text, True, color)
        x = (W - surf.get_width()) // 2
        y = (H - surf.get_height()) // 2 + y_offset
        self.screen.blit(surf, (x, y))
