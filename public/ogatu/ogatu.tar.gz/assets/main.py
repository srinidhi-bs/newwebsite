# =============================================================================
# main.py  -  Entry point.
#
# Run the game:
#   python main.py                 # normal: lands on the HOME menu
#   python main.py --level 5       # DEV/TESTING shortcut: skip the menu + intro
#                                  # and drop straight into level 5 (1-based).
# =============================================================================
import argparse
import asyncio

# Imported here even though main.py doesn't call pygame directly: pygbag only
# loads + finishes wiring the pygame-ce WebAssembly extension when it sees
# `import pygame` in the MAIN module. Without this, the browser build imports
# game.py's pygame as an empty stub ("module 'pygame' has no attribute 'init'").
import pygame  # noqa: F401  (presence matters, not direct use)
from game import Game
from constants import LEVELS


def main():
    parser = argparse.ArgumentParser(
        description="Ogatu - a digging riddle",
        # Keep --help quiet about things users don't need; we only add --level.
    )
    parser.add_argument(
        "--level", type=int, metavar="N", default=None,
        help=("skip the menu/intro and start directly at level N (1-based). "
              "A dev/testing shortcut - e.g. `python main.py --level 5`. "
              "Out-of-range values fall back to the normal menu start."),
    )
    args = parser.parse_args()

    start = None
    if args.level is not None:
        # The command line is 1-based ("level 1" = the first cave); the engine
        # is 0-based. Clamp/guard so a bad number never crashes the launch.
        if 1 <= args.level <= len(LEVELS):
            start = args.level - 1
        else:
            print(f"--level {args.level} is out of range "
                  f"(1..{len(LEVELS)}); starting at the HOME menu.")

    # Construct AND run the game INSIDE the coroutine. This matters for the
    # pygbag/web build: pygame-ce only finishes wiring up once we're inside the
    # event loop, so building Game (which calls pygame.init()) before the loop -
    # the obvious `asyncio.run(Game(...).run())` - crashes the browser build with
    # "module 'pygame' has no attribute 'init'". On the desktop it's equivalent.
    async def _amain():
        await asyncio.sleep(0)        # let the browser runtime settle (no-op on desktop)
        await Game(start_level=start).run()

    asyncio.run(_amain())


if __name__ == "__main__":
    main()
