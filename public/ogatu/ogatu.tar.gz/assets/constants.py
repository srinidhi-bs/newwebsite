# =============================================================================
# constants.py  -  All tunable values + the level maps for the Ogatu game.
#
# This file is intentionally FREE of any pygame import so that the pure game
# logic in engine.py can be unit-tested headlessly (without opening a window).
# Colors are plain (R, G, B) tuples that pygame can use directly later.
#
# Boulder Dash recap (what these tiles mean):
#   The whole screen is a flat 2D "slice of earth" viewed face-on. Gravity pulls
#   everything toward the BOTTOM of the screen. You (Ranganna) dig through dirt,
#   collect every diamond, drop boulders on fireflies, and reach the exit.
# =============================================================================

# ---- Window / timing --------------------------------------------------------
TILE_SIZE = 36          # pixel size of one grid cell (square)
HUD_HEIGHT = 46         # pixels reserved at the top for the score/lives bar
FPS = 60                # frames per second the main loop targets

# How often (in milliseconds) each subsystem is allowed to "step". Boulder Dash
# is a grid game that runs in real time, so movement/gravity/enemies each tick
# on their own timer. Tuning these changes the FEEL of the game.
MOVE_INITIAL_MS = 200   # delay before auto-repeat starts (the first move on
                        # key-down is immediate; this delay prevents accidental
                        # double-moves on a quick tap - responsive + fair)
MOVE_REPEAT_MS = 140    # how fast movement repeats once auto-repeat is going
GRAV_MS = 140           # how often boulders fall one tile
ENEMY_MS = 230          # how often each firefly takes a step
HUNTER_MS = 260         # how often a HUNTER takes a step - deliberately SLOWER
                        # than the 140ms player auto-repeat (and the 230ms
                        # wall-followers) so you can outrun it in the open but
                        # get cornered in tight tunnels. Live-tunable difficulty knob.
# ---- Dynamite (a planted bomb) ----------------------------------------------
BOMB_MS = 320           # how often a planted bomb's fuse ticks down one notch
BOMB_FUSE_TICKS = 3     # bomb detonates this many BOMB_MS ticks after planting
                        # (~1s at 320ms). Lower = less time to flee. Live-tunable.

# ---- Scoring / lives --------------------------------------------------------
START_LIVES = 3
DIAMOND_SCORE = 10      # points per diamond collected
ENEMY_SCORE = 75         # bonus for crushing any enemy (firefly or butterfly)
DIAMONDS_PER_LIFE = 0   # set >0 to award an extra life every N diamonds (off in v1)

# ---- Dynamite economy (the store) -------------------------------------------
START_BOMBS = 1         # bombs you begin each cave holding
DIAMONDS_PER_BOMB = 5   # store price: this many WALLET diamonds buys one bomb.
                        # Spending never reduces diamonds_collected (the exit
                        # counter), so buying can't re-lock a cave - see engine.

# ---- Tile characters used inside level maps ---------------------------------
WALL = "#"              # solid steel cave boundary - nothing can pass, never digs
DIRT = "."              # soft earth - player digs it by walking into it
EMPTY = " "             # open tunnel - everything can move through here
BOULDER = "B"           # heavy rock - falls when unsupported; crushes what's below
DIAMOND = "D"           # gem - collect it; collecting all of them opens the exit
EXIT = "E"              # the level exit - only enterable once enough gems collected

# A bomb is a runtime tile: it never appears in a level map, only where the
# player plants one (engine.place_bomb). It sits in the grid like a boulder so
# rocks rest on it (BOMB is in BOULDER_SUPPORTS) and it blocks movement.
BOMB = "*"              # a live, ticking bomb planted by the player

# These two only exist in the level TEXT; at load time they become moving
# "entities" tracked separately from the static-ish grid.
PLAYER_SPAWN = "P"      # where Ranganna starts (cell becomes EMPTY)
FIREFLY_SPAWN = "F"     # where each enemy starts (cell becomes EMPTY)
BUTTERFLY_SPAWN = "T"   # where each butterfly starts (cell becomes EMPTY)
HUNTER_SPAWN = "H"      # where a hunter starts (it chases the player; cell -> EMPTY)

# Tiles that support a falling object (boulder OR diamond) so it rests.
BOULDER_SUPPORTS = (WALL, DIRT, BOULDER, DIAMOND, EXIT, BOMB)

# ---- Colors (R, G, B) -------------------------------------------------------
COL_BG       = (18, 16, 26)
COL_EMPTY    = (24, 20, 34)
COL_WALL     = (78, 78, 92)
COL_DIRT     = (132, 84, 54)
COL_BOULDER  = (150, 150, 162)
COL_DIAMOND  = (90, 224, 236)
COL_EXIT_OFF = (70, 64, 80)     # exit door before it's activated (locked)
COL_EXIT_ON  = (96, 240, 130)   # exit door once enough diamonds collected
COL_PLAYER   = (255, 214, 70)
COL_FIREFLY  = (255, 96, 44)
COL_BUTTERFLY = (190, 120, 225)  # purple-magenta - distinct from the orange firefly
COL_HUNTER   = (224, 36, 48)     # crimson - the chasing hunter; an angular "danger
                                 # star" silhouette keeps it distinct from the orange
                                 # firefly even for colour-blind players
COL_BOMB       = (44, 42, 56)    # dark rounded bomb body
COL_BOMB_SPARK = (255, 176, 60)  # fuse spark; flashes to red as the fuse runs out
COL_HUD      = (12, 11, 20)
COL_HUD_LINE = (60, 56, 80)
COL_TEXT     = (236, 236, 246)
COL_TEXT_DIM = (150, 146, 168)
COL_GOOD     = (96, 240, 130)
COL_BAD      = (255, 90, 90)

# ---- Level maps -------------------------------------------------------------
# Each level is a list of equal-length strings (20 wide x 12 tall). The loader
# pads short rows with WALL so the cave stays rectangular.
#
# Design notes:
#   * Every level is 20 wide x 12 tall. Boulders ('B') and diamonds ('D') MUST
#     have a solid tile directly beneath them at load time (otherwise the cave
#     settles chaotically on tick 1 - the headless tests enforce this).
#   * Enemies need EMPTY space around them to patrol; a firefly/butterfly boxed
#     in dirt at load time won't move until you dig next to it.
#   * Each level now uses a DISTINCT archetype (vertical barriers, a winding
#     tunnel, a walled chamber, boulder drop-shafts...) rather than one shared
#     layout - see LEVEL_NAMES. Crushing a firefly clears dirt (no gems); a
#     butterfly explodes into bonus diamonds.
#   * DIFFICULTY CURVE (standing rule): each level MUST play harder than the one
#     before it. Ramp via more/faster enemies, tighter timing, longer routes,
#     more boulders, or scarcer safe space - never an easier cave later in the
#     run. When editing or adding a level, check it against its predecessor.
#
# Legend:  # wall   . dirt   (space) empty   B boulder   D diamond
#          E exit   P player start   F firefly start   T butterfly start

LEVELS = [
    # ---- Level 1: "First Dig" ---------------------------------------------
    # 5 diamonds, 1 patrolling firefly. Pure tutorial.
    [
        "####################",
        "#P...D......D......#",
        "#..................#",
        "#..B...D.....B.....#",
        "#..................#",
        "#                  #",
        "#       F          #",
        "#                  #",
        "#..................#",
        "#..D...B......D....#",
        "#................E.#",
        "####################",
    ],
    # ---- Level 2: "The Descent" ------------------------------------------
    # Vertical descent through three stacked dirt chambers (WALL barriers, one
    # drop-gap each). Each chamber holds one firefly: the TOP roams a box on the
    # LEFT while the gem waits on the right; the MIDDLE paces a horizontally
    # CENTRED slot; the BOTTOM orbits a full 3x3 RING around a dirt pivot.
    # (Silhouette: stacked layers.)
    [
        "####################",
        "#P.    .......D....#",
        "#.. F  ............#",
        "############### ####",
        "#..B...........D...#",
        "#......  F   ......#",
        "#....D.............#",
        "#### ###############",
        "#........   .D.....#",
        "#........ . .......#",
        "#.D......  F.....E.#",
        "####################",
    ],
    # ---- Level 3: "The Coil" ----------------------------------------------
    # A pre-carved SERPENTINE tunnel (empty corridors winding through walls).
    # You walk the path rather than dig it; TWO fireflies patrol the coil.
    # Diamonds sit at the bends. (Silhouette: a single winding dark corridor.)
    [
        "####################",
        "#P                 #",
        "#################.##",
        "#        F        D#",
        "#.################.#",
        "#D                 #",
        "#.##.############.##",
        "#          F      D#",
        "##.#################",
        "#D                 #",
        "#.################E#",
        "####################",
    ],
    # ---- Level 4: "The Hive" ----------------------------------------------
    # A walled chamber with a hollow centre. ONE butterfly circles the outer
    # perimeter while ONE firefly orbits the central gem (it spawns beside the
    # gem and wall-follows the 1x2 pedestal island - a tighter inner loop that
    # never collides with the perimeter butterfly). You must time the doorway
    # entry (bottom) AND slip past the firefly to grab the centre gem, which
    # rests on a dirt pedestal so it stays put instead of falling to the floor.
    # Two SIDE guards add to the threat: a butterfly (left band) and a firefly
    # (right band), each patrolling its own small OPEN pocket carved into the dirt
    # around a wall-hugging gem (gems shifted one cell inward; each gem rests on a
    # single dirt pedestal so it doesn't fall). The pockets are sealed by dirt, so
    # a guard orbits its gem until you dig in to grab it - then it's loose on you.
    # (Silhouette: a boxed room + a 2-enemy gauntlet + two pocket guards.)
    [
        "####################",
        "#P......D..........#",
        "#..................#",
        "#....##########....#",
        "#....#  T     #....#",
        "#   .#  FD    #.   #",
        "#TD .#   .    #. DF#",
        "# . .#        #. . #",
        "#....##### ####....#",
        "#..................#",
        "#.D..............E.#",
        "####################",
    ],
    # ---- Level 5: "Boulder Drop" ------------------------------------------
    # Vertical drop-shafts: a boulder sits on a dirt ledge above each shaft;
    # a butterfly patrols the shaft below. Dig the ledge to drop the rock and
    # crush the butterfly into bonus diamonds. Placed gems meet the goal on
    # their own; the crushes are a reward. (Silhouette: a boulder-studded
    # ceiling over columns.)
    [
        "####################",
        "#P.................#",
        "#....D........D....#",
        "#..B...B...B...B...#",
        "#..................#",
        "#.. ... ... ... ...#",
        "#.. ... ... ... ...#",
        "#.. ... ... ... ...#",
        "#.. ... .D. ... ...#",
        "#..T...T...T...T...#",
        "#....D......D.....E#",
        "####################",
    ],
    # ---- Level 6: "The Hunt" ----------------------------------------------
    # The HARDEST cave (difficulty-curve standing rule). Debuts the HUNTER - the
    # first enemy that actively CHASES (BFS shortest-path; see engine). A 3-tall
    # EMPTY "highway" splits the cave mid-way; the hunter LURKS there, frozen,
    # until you dig a tunnel that connects to it - then it bolts along the
    # shortest open path toward you. It can't dig, so undug dirt is your refuge.
    # Half the diamonds + the exit sit BELOW the highway, so you MUST cross the
    # hunter's lair to finish. Two boulders rest on 1-tile dirt ledges over the
    # highway: dig a ledge to drop a rock and crush the hunter into bonus gems
    # (a reward, not required - the 10 placed diamonds already meet the goal).
    # (Silhouette: two dirt banks split by an open chasm.)
    [
        "####################",
        "#P..D......D....D..#",
        "#......D....D......#",
        "#.....B.......B....#",
        "#     .       .    #",
        "#                  #",
        "#        H         #",
        "#..................#",
        "#..D....D....D.....#",
        "#.....D......D.....#",
        "#...............E..#",
        "####################",
    ],
]

# Sanity: keep every level the same size so the window never needs to resize.
LEVEL_COLS = len(LEVELS[0][0])
LEVEL_ROWS = len(LEVELS[0])

# Display names for the Level Select menu (one per level above). Adding a level
# means appending both a map to LEVELS and a name here so they stay in lockstep.
LEVEL_NAMES = ["First Dig", "The Descent", "The Coil", "The Hive", "Boulder Drop", "The Hunt"]
