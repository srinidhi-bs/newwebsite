# =============================================================================
# sound.py  -  Procedural sound effects for game-digger.
#
# Every sound in this file is GENERATED in code at launch time - there are no
# audio asset files (game_clip2.ogg, the intro music, is the project's one and
# only asset). We build short PCM waveforms with the Python standard library
# (struct + io + math + array + random), wrap each as an in-memory WAV, and hand
# it to pygame.mixer.Sound. This keeps the project at a single dependency
# (pygame) and matches the "everything is drawn/generated in code" ethos that
# the vector graphics already follow.
#
# Why simple synthesis sounds right here: Boulder Dash (1984) was an 8-bit game,
# so retro bleeps, square-wave blips, and noise bursts suit it perfectly - a
# "cheap" procedural sound is period-appropriate, not a compromise.
#
# Design split: each _make_* function returns the RAW float buffer (+ a volume),
# with NO pygame dependency. SfxBank converts those buffers to mixer.Sound
# objects at startup. This keeps the synthesis unit-testable headlessly (the
# dummy audio driver can build buffers but not Sounds). game.py calls
# SfxBank.play(name) at the right moments; this module knows no game rules.
# =============================================================================

import math
import random
import array

import pygame

# All sounds are generated at SAMPLE_RATE (the mixer's default rate). We
# synthesise MONO floats, then in _to_sound duplicate each sample across the
# mixer's ACTUAL channel count (get_init) so they play at the right pitch on
# desktop AND in the browser - no numpy, no WAV files.
SAMPLE_RATE = 44100


# ---------------------------------------------------------------------------
# Low-level waveform + envelope generators. Each returns a list of float
# samples in the range [-1, 1]; sounds are built by mixing/sequencing these.
# These are pure math (no pygame) so they can be unit-tested headlessly.
# ---------------------------------------------------------------------------
def _sine(freq, dur, sr=SAMPLE_RATE):
    """A pure sine wave of `freq` Hz lasting `dur` seconds. Smooth + musical."""
    n = int(sr * dur)
    return [math.sin(2 * math.pi * freq * i / sr) for i in range(n)]


def _square(freq, dur, sr=SAMPLE_RATE):
    """A square wave of `freq` Hz - rich, buzzy, very 8-bit/retro."""
    n = int(sr * dur)
    return [1.0 if math.sin(2 * math.pi * freq * i / sr) >= 0 else -1.0
            for i in range(n)]


def _noise(dur, sr=SAMPLE_RATE):
    """White noise (uniformly random samples) - raw material for digs, crushes,
    and explosions."""
    n = int(sr * dur)
    return [random.uniform(-1, 1) for i in range(n)]


def _env_exp(dur, decay=6.0, sr=SAMPLE_RATE):
    """An exponential decay envelope from 1.0 toward 0 over `dur` seconds.
    `decay` controls how fast it dies (higher = shorter tail). Exponential decay
    mimics a plucked string / a struck object - natural-sounding for SFX."""
    n = int(sr * dur)
    if n <= 0:
        return []
    return [math.exp(-decay * i / n) for i in range(n)]


def _sequence(tones, sr=SAMPLE_RATE):
    """Play a melody: concatenate a list of (freq, dur, decay) notes, each given
    a sine wave + exponential-decay envelope. Returns one float buffer. Used for
    the arpeggio-like win/lose/UI sounds."""
    buf = []
    for freq, dur, decay in tones:
        wave_data = _sine(freq, dur)
        env = _env_exp(dur, decay)
        buf.extend(wave_data[i] * env[i] for i in range(len(wave_data)))
    return buf


def _to_sound(buf_float, volume=0.5):
    """Turn a float-sample buffer in [-1, 1] into a playable pygame.mixer.Sound.

    We hand pygame RAW PCM via Sound(buffer=...) instead of wrapping the samples
    in a WAV and loading them (Sound(file=...)): the browser/WebAssembly mixer
    (pygbag) refuses to read a Sound from a Python file object - it raises
    "can't access resource on platform" - whereas buffer= works on desktop AND
    web. `volume` (0..1) scales the whole sound. We match the mixer's real
    channel count (get_init) by duplicating each mono sample across the channels
    so nothing plays at the wrong speed."""
    init = pygame.mixer.get_init()           # (freq, size, channels) or None
    channels = init[2] if init else 1
    peak = int(32767 * volume)
    samples = array.array('h')               # signed 16-bit PCM
    for v in buf_float:
        s = int(peak * max(-1.0, min(1.0, v)))   # clamp to [-1, 1], then scale
        for _ in range(channels):            # interleave mono -> L/R(/...)
            samples.append(s)
    return pygame.mixer.Sound(buffer=samples.tobytes())


# ---------------------------------------------------------------------------
# The ten sound effects, as raw float buffers. Each returns (buffer, volume);
# SfxBank converts to Sound. Volumes are per-sound so they sit well together -
# digs are subtle, explosions are loud, UI blips are soft.
# ---------------------------------------------------------------------------
def _make_dig():
    """A short crunchy noise burst - digging through dirt. Fast decay = snappy."""
    dur = 0.08
    noise = _noise(dur)
    env = _env_exp(dur, decay=14.0)          # dies fast: a tick, not a hiss
    buf = [noise[i] * env[i] for i in range(len(noise))]
    return buf, 0.30


def _make_collect():
    """Grabbing a diamond: a bright two-note rising blip (A5 -> E6). Rewarding."""
    buf = _sequence([(880, 0.06, 8.0), (1320, 0.10, 6.0)])
    return buf, 0.45


def _make_crush():
    """Player crushed by a boulder: a low thud (noise + low tone, quick). Heavy."""
    dur = 0.22
    noise = _noise(dur)
    thud = _sine(90, dur)                    # low boom underneath
    env = _env_exp(dur, decay=7.0)
    buf = [(0.55 * noise[i] + 0.45 * thud[i]) * env[i] for i in range(len(noise))]
    return buf, 0.60


def _make_explosion():
    """Firefly crushed into diamonds: a bigger noise burst - a satisfying boom."""
    dur = 0.30
    noise = _noise(dur)
    env = _env_exp(dur, decay=5.0)           # slower decay than the dig
    buf = [noise[i] * env[i] for i in range(len(noise))]
    return buf, 0.55


def _make_menu_move():
    """Moving the menu cursor: a tiny, soft square-wave tick. Unobtrusive."""
    dur = 0.045
    sq = _square(520, dur)
    env = _env_exp(dur, decay=16.0)
    buf = [sq[i] * env[i] for i in range(len(sq))]
    return buf, 0.20


def _make_menu_confirm():
    """Confirming a menu choice: a two-note rising square blip (C5 -> G5)."""
    a = _square(523, 0.07)                       # C5
    b = _square(784, 0.11)                       # G5
    ea = _env_exp(0.07, 9.0)
    eb = _env_exp(0.11, 6.0)
    buf = [a[i] * ea[i] for i in range(len(a))] + \
          [b[i] * eb[i] for i in range(len(b))]
    return buf, 0.30


def _make_level_complete():
    """Clearing a cave: a cheerful ascending arpeggio (C-E-G-C)."""
    buf = _sequence([(523, 0.09, 5.0), (659, 0.09, 5.0),
                     (784, 0.09, 5.0), (1047, 0.18, 3.0)])
    return buf, 0.45


def _make_game_over():
    """Out of lives: a descending, resigned phrase (G-E-C, lower octave)."""
    buf = _sequence([(392, 0.16, 3.5), (330, 0.16, 3.5), (262, 0.30, 2.5)])
    return buf, 0.50


def _make_victory():
    """Cleared every cave: a bright triumphant arpeggio (C-E-G-C-G-C)."""
    buf = _sequence([(523, 0.09, 5.0), (659, 0.09, 5.0), (784, 0.09, 5.0),
                     (1047, 0.14, 3.0), (784, 0.09, 5.0), (1047, 0.25, 2.0)])
    return buf, 0.50


def _make_exit_unlock():
    """Enough diamonds collected - the exit opens: a high shimmering chime."""
    buf = _sequence([(1047, 0.07, 6.0), (1319, 0.07, 6.0), (1568, 0.14, 3.0)])
    return buf, 0.40


# The canonical set of sound names game.py may request.
SOUND_NAMES = ("dig", "collect", "crush", "explosion", "menu_move",
               "menu_confirm", "level_complete", "game_over", "victory",
               "exit_unlock")

# Maps each name to the function that builds its raw buffer. SfxBank builds the
# actual mixer.Sound objects once at startup so playback is a cheap .play().
_BUILDERS = {
    "dig": _make_dig,
    "collect": _make_collect,
    "crush": _make_crush,
    "explosion": _make_explosion,
    "menu_move": _make_menu_move,
    "menu_confirm": _make_menu_confirm,
    "level_complete": _make_level_complete,
    "game_over": _make_game_over,
    "victory": _make_victory,
    "exit_unlock": _make_exit_unlock,
}


class SfxBank:
    """Holds every procedural sound effect and plays them on demand.

    Build once after the mixer is up (Game.__init__). play(name) is a guarded
    no-op if audio is off, the bank is empty, or the player has muted it - so the
    game never crashes over a missing sound. `muted` is in-memory only (per
    session), matching how the avatar choice already works.
    """

    def __init__(self, audio_ok):
        self.muted = False
        self.sounds = {}
        if not audio_ok:
            return
        for name, builder in _BUILDERS.items():
            try:
                buf, vol = builder()
                self.sounds[name] = _to_sound(buf, volume=vol)
            except pygame.error:
                # A single broken sound shouldn't take the rest down; play()
                # just skips any name that failed to build.
                pass

    def play(self, name):
        """Play `name` unless muted/missing. Always safe to call."""
        if self.muted or name not in self.sounds:
            return
        try:
            self.sounds[name].play()
        except pygame.error:
            pass

    def toggle_mute(self):
        """Flip mute on/off. Returns the new muted state."""
        self.muted = not self.muted
        return self.muted
